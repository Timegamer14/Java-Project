package matchgame;


import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLayeredPane;
import javax.swing.JButton;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;

import java.awt.Font;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;
import java.awt.Color;


import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;

import javax.swing.ImageIcon;

import java.awt.event.ActionListener;
import java.io.File;



import java.awt.event.ActionEvent;
import javax.swing.Timer;
import javax.swing.JLabel;

@SuppressWarnings("serial")
public class Matchgame1 extends JFrame {

	private JPanel contentPane;                     // Panel for game
	JOptionPane scorePane = new JOptionPane();      //score pane	
	JButton GreenLight;                            // Green button
	JButton YellowLight;                             //Yellow button
	JButton BlueLight;                                // Blue button
	JButton RedLight;                                 // Red button
	Color normYellow = new Color(204, 204, 0);          //yellow Color
	Color normRed = new Color(139, 0, 0);               //red Color
	Color normGreen = new Color(0, 128, 0);             //Green Color
	Color normBlue = new Color(0, 0, 205);              //Blue color
	Color brightBlue = new Color(0, 191, 255);          //Bright Blue
    private Timer timer;                                 //Timer
    private Timer greenTimer;                           // Green Timer
    private Timer blueTimer;                           // Blue Timer
    private Timer yellowTimer;                        // yellow Timer
    private Timer redTimer;                          // REd timer
    private Timer doNothing;                        // Do nothing timer
    JLabel turnOrder;                               // Label turn order
    int sequence = 0;                                // sequence
    public static Integer score = 0;                                  // score
    public static Integer Level = 1;                                   // level
	
	String initials;                                                                                   // initials
	Sequence seq = new Sequence();  
	// Create a new List<Boolean>
	
	// Function to check the score of the game
	void checkScore() {
	    // If the score is less than 0, display a game over message
	    if (score < 0) {
	        JOptionPane.showMessageDialog(null, "Game over! You lost.");
	        
	        // Placeholder for high score update logic
	    }
	}

	// Function to check the level of the game and adjust points accordingly
	void Levelchecker(JLabel Levelpoint, JLabel currentScore) {
	    // Initialize counters for points to be added or deducted
	    int pointsAdded = 0;
	    int pointsDeducted = 0;
	    
	    // Adjust points based on the current level
	    switch (Level) {
	        case 1:
	            pointsAdded = 10;
	            pointsDeducted = 20;
	            break;
	        case 2:
	            pointsAdded = 20;
	            pointsDeducted = 40;
	            break;
	        case 3:
	            pointsAdded = 40;
	            pointsDeducted = 80;
	            break;
	        case 4:
	            pointsAdded = 80;
	            pointsDeducted = 160;
	            break;
	        default:
	            // Handle cases where the level exceeds 4 if necessary
	            break;
	    }

	    // If it's the end of the turn, add points. Otherwise, deduct points.
	    if (seq.turnOver()) {
	        score += pointsAdded;
	        currentScore.setText("" + score);
	    } else {
	        score -= pointsDeducted;
	        currentScore.setText("" + score);
	    }

	    // Update level if the score has reached a certain threshold
	    if (score >= 40 * Level) {
	        Level++;
	        Levelpoint.setText("" + Level); // Update the level display
	    }
	}

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) { //main
		EventQueue.invokeLater(new Runnable() { //run the application
			public void run() {
				try {
					Matchgame1 frame = new Matchgame1(); //game
					frame.setVisible(true);// open as a screen
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	// Constructor for the Matchgame1 class
	public Matchgame1() {
			
	    // Set the close operation and size of the game window
	    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    setBounds(100, 100, 428, 590);

	    // Timer that does nothing for 200ms, used for delaying actions
	    doNothing = new Timer(200, new ActionListener() {
	        // Stop the timer when it is triggered
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            doNothing.stop();
	        }
	    });

	    // Timer for the green light that lasts for 100ms
	    greenTimer = new Timer(100, new ActionListener() {
	        @Override
	        public void actionPerformed(ActionEvent e) {
	            // Playing a bell sound when the green light is on
	            String dingLocation3 = "Audio/bell.wav";
	            try {
	                File dingFile = new File(dingLocation3);
	                AudioInputStream dingAudioFile = AudioSystem.getAudioInputStream(dingFile);
	                Clip dingSound = AudioSystem.getClip();
	                dingSound.open(dingAudioFile);
	                dingSound.start();
	            } catch (Exception e1) {
	                JOptionPane.showMessageDialog(null, "Problem playing sound");
	            }

	            // Change the background color of the green light to normal and stop the timer
	            GreenLight.setBackground(normGreen);
	            greenTimer.stop();
	        }
	    });
		// Initialize a Timer for the blue light with a delay of 150ms
		// and an ActionListener to play a sound, change the background color of the blue light to normal color, and stop the Timer when it's triggered
		blueTimer = new Timer(100, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String dingLocation3 = "Audio/bell.wav";

				try {
					File dingFile = new File(dingLocation3);
					AudioInputStream dingAudioFile = AudioSystem.getAudioInputStream(dingFile);
					Clip dingSound = AudioSystem.getClip();
					dingSound.open(dingAudioFile);
					dingSound.start();
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, "Problem playing sound");
				}
				BlueLight.setBackground(normBlue);
				blueTimer.stop();
			}
		});

		// Initialize a Timer for the yellow light with a delay of 150ms
		// and an ActionListener to play a sound, change the background color of the yellow light to normal color, and stop the Timer when it's triggered
		yellowTimer = new Timer(100, new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				String dingLocation3 = "Audio/bell.wav";

				try {
					File dingFile = new File(dingLocation3);
					AudioInputStream dingAudioFile = AudioSystem.getAudioInputStream(dingFile);
					Clip dingSound = AudioSystem.getClip();
					dingSound.open(dingAudioFile);
					dingSound.start();
				} catch (Exception e1) {
					JOptionPane.showMessageDialog(null, "Problem playing sound");
				}
				YellowLight.setBackground(normYellow);
				yellowTimer.stop();
			}
		});

		// Initialize a Timer for the red light with a delay of 150ms
		// and an ActionListener to play a sound, change the background color
		
		redTimer = new Timer(100, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	String dingLocation3 = "Audio/bell.wav";
				
				try {
					File dingFile = new File(dingLocation3);
					
					AudioInputStream dingAudioFile = AudioSystem.getAudioInputStream(dingFile);
					
					Clip dingSound = AudioSystem.getClip();
					
					dingSound.open(dingAudioFile);
					dingSound.start();
				
				} catch (Exception e1) {
					
					JOptionPane.showMessageDialog(null, "Problem playing sound");
				}
                RedLight.setBackground(normRed);
                redTimer.stop();
            }
        });

		timer = new Timer(600, new ActionListener() {
		    // ActionListener for timer
		    @Override
		    public void actionPerformed(ActionEvent e) {
		        // Show a message dialog for the player to start the game
		       
		        // If any of the lights are on, turn them off
		        if (RedLight.getBackground().equals(Color.RED) ||
		                GreenLight.getBackground().equals(Color.GREEN) ||
		                BlueLight.getBackground().equals(Color.BLUE) ||
		                YellowLight.getBackground().equals(Color.YELLOW)) {
		            RedLight.setBackground(normRed);
		            GreenLight.setBackground(normGreen);
		            BlueLight.setBackground(normBlue);
		            YellowLight.setBackground(normYellow);
		        }
		      //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		    	// Method				: Colour Timer
		    	//
		    	// Method parameters	: Red blue yellow green
		    	//
		    	// Method return		:
		    	//
		    	// 
		    	//
		    	// Modifications		:
		    	//							Date			Developer			Notes
		    	//							----			---------			-----
		    	//							2023-05-15		DhruvitPatel		None.
		    	//
		    	//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		        // If the sequence is not complete, show the next character
		        else if (sequence < seq.getSequence().size()) {
		            switch(seq.getSequenceChar(sequence)) {
		                // Show the yellow light and play the sound
		                case 'Y':
		                    YellowLight.setBackground(Color.YELLOW);
		                    String dingLocation3 = "Audio/ding.wav";
		                    try {
		                        File dingFile = new File(dingLocation3);
		                        AudioInputStream dingAudioFile = AudioSystem.getAudioInputStream(dingFile);
		                        Clip dingSound = AudioSystem.getClip();
		                        dingSound.open(dingAudioFile);
		                        dingSound.start();
		                    } catch (Exception e1) {
		                        JOptionPane.showMessageDialog(null, "Problem playing sound");
		                    }
		                    break;
		                // Show the blue light and play the sound
		                case 'B':
		                    BlueLight.setBackground(brightBlue);
		                    String dingLocation4 = "Audio/ding.wav";
		                    try {
		                        File dingFile = new File(dingLocation4);
		                        AudioInputStream dingAudioFile = AudioSystem.getAudioInputStream(dingFile);
		                        Clip dingSound = AudioSystem.getClip();
		                        dingSound.open(dingAudioFile);
		                        dingSound.start();
		                    } catch (Exception e1) {
		                        JOptionPane.showMessageDialog(null, "Problem playing sound");
		                    }
		                    break;
		                // Show the green light and play the sound
		                case 'G':
		                    GreenLight.setBackground(Color.GREEN);
		                    String dingLocation5 = "Audio/ding.wav";
		                    try {
		                        File dingFile = new File(dingLocation5);
		                        AudioInputStream dingAudioFile = AudioSystem.getAudioInputStream(dingFile);
		                        Clip dingSound = AudioSystem.getClip();
		                        dingSound.open(dingAudioFile);
		                        dingSound.start();
		                    } catch (Exception e1) {
		                        JOptionPane.showMessageDialog(null, "Problem playing sound");
		                    }
		                    break;
		                // Show the red light and play the sound
		                case 'R':
		                    RedLight.setBackground(Color.RED);
		                    String dingLocation6 = "Audio/ding.wav";
		                    try {
		                        File dingFile = new File(dingLocation6);
		                        AudioInputStream dingAudioFile = AudioSystem.getAudioInputStream(dingFile);
		                        Clip dingSound = AudioSystem.getClip();
		                        dingSound.open(dingAudioFile);
		                        dingSound.start();
		                    } catch (Exception e1) {
		                        JOptionPane.showMessageDialog(null, "Problem playing sound");
		                    }
		                    break;
		                default:
		                    break;
		            }
		            // Move on to the next character in the sequence
		            sequence++;
		        } else {
		            // Reset the sequence and stop the timer
		            sequence = 0;
		            timer.stop();
		        }
		    }
		});
		
		// Setup the main panel
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));  // Set border spacing
		contentPane.setLayout(new BorderLayout(0, 0));  // Set layout as BorderLayout
		setContentPane(contentPane);  // Set this panel as content pane

		// Create layered pane for the game
		JLayeredPane gamePlane = new JLayeredPane();
		contentPane.add(gamePlane, BorderLayout.CENTER);  // Add game plane to the center of the layout

		// Create and setup label for the score
		JLabel ScoreHeader = new JLabel("Score:");
		ScoreHeader.setFont(new Font("Tahoma", Font.BOLD, 25));  // Set label font
		gamePlane.setLayer(ScoreHeader, 1);  // Set this label to layer 1
		ScoreHeader.setBounds(36, 403, 185, 33);  // Set label position and size
		gamePlane.add(ScoreHeader);  // Add label to the game plane

		// Create and setup label for the current score
		JLabel CurrentScore = new JLabel("" + score);
		CurrentScore.setFont(new Font("Tahoma", Font.BOLD, 34));  // Set label font
		gamePlane.setLayer(CurrentScore, 1);  // Set this label to layer 1
		CurrentScore.setBounds(221, 391, 140, 48);  // Set label position and size
		gamePlane.add(CurrentScore);  // Add label to the game plane

		// Create and setup label for the level
		JLabel Level1= new JLabel("Level:");
		Level1.setBounds(36, 446, 107, 33);
		Level1.setFont(new Font("Tahoma", Font.BOLD, 34));
		gamePlane.add(Level1);

		// Create and setup label for the level points
		JLabel Levelpoint = new JLabel("0");
		Levelpoint.setBounds(221, 446, 45, 33);
		Levelpoint.setFont(new Font("Tahoma", Font.BOLD, 34));
		gamePlane.add(Levelpoint);

		// Create and setup the Play button
		JMenuItem PlayBtn = new JMenuItem("New Game");
		PlayBtn.setBounds(10, 508, 156, 25);
		gamePlane.add(PlayBtn);

		// Add action listener to the Play button
		PlayBtn.addActionListener(new ActionListener() {
		    @Override
		    public void actionPerformed(ActionEvent e) {
		        // Reset game variables
		        score = 0;
		        CurrentScore.setText("" + score);
		        Level = 0;
		        Levelpoint.setText("" + Level);

		        timer.stop();
		        turnOrder.setText("Match Game");
		        seq = new Sequence();
		        sequence = 0;
		        timer.start();
		        
		        // Enable all buttons
		        enableButtons(GreenLight, RedLight, BlueLight, YellowLight);
		    }

		    // Method to enable all buttons
		    private void enableButtons(JButton GreenLight, JButton RedLight, JButton BlueLight, JButton YellowLight) {
		        GreenLight.setEnabled(true);
		        RedLight.setEnabled(true);
		        BlueLight.setEnabled(true);
		        YellowLight.setEnabled(true);
		    }
		});

		
        // Set the horizontal text position of the Play button to the center
PlayBtn.setHorizontalTextPosition(SwingConstants.CENTER);

        // Set the background color of the Play button to orange
PlayBtn.setBackground(new Color(255, 69, 0));

         // Set the border of the Play button to a raised bevel border with light gray and dark gray colors
PlayBtn.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, Color.LIGHT_GRAY, Color.DARK_GRAY));

          // Set the horizontal alignment of the Play button to the center
PlayBtn.setHorizontalAlignment(SwingConstants.CENTER);

            // Set the font of the Play button to "Segoe UI" with a bold size of 15
PlayBtn.setFont(new Font("Segoe UI", Font.BOLD, 15));
	
		
		
		turnOrder = new JLabel("");
		turnOrder.setFont(new Font("Dialog", Font.BOLD, 27));
		turnOrder.setHorizontalTextPosition(SwingConstants.CENTER);
		turnOrder.setHorizontalAlignment(SwingConstants.CENTER);
		turnOrder.setBounds(6, -1, 391, 58);
		gamePlane.add(turnOrder);
		
		
		
		//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		// Method				: 4 Different Colour button 
		//
		// Method parameters	:  JButton RedButton, JButton GreenButton, JButton YellowButton, JButton BlueButton
		//
		// Method return		:
		//
		// Synopsis				: Keeps track of button presses.
		//
		// Modifications		:
		//							Date			Developer			Notes
		//							----			---------			-----
		//							2023-05-15		A Dhruvit			None.
		//
		//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		
		// This block creates a JButton "GreenLight" and sets up its behavior on being clicked.
		GreenLight = new JButton("");
		GreenLight.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {

		        // Changes the button's color to green and starts a timer.
		        GreenLight.setBackground(Color.GREEN);
		        greenTimer.stop();
		        greenTimer.start();

		        // Checks if the user's guess ('G' for green) is correct.
		        if(seq.userInput('G') == true) {

		            // If the user's turn is over (they've made all their guesses for this round), they get a score increase.
		            if(seq.turnOver()) {
		                turnOrder.setText("Correct! Score Up!");
		                score += 10 * Level;
		                
		                Levelchecker(Levelpoint, CurrentScore);
		                CurrentScore.setText("" + score);
		                doNothing.start();
		                seq.getUserGuessSequence().clear();
		                nextTurn();
		            }

		            // If the turn isn't over, they're encouraged to continue guessing.
		            else {
		                turnOrder.setText("Go on...");
		            }
		        }

		        // If the user's guess is incorrect, they're told that the game is over, and their score is decreased.
		        else {
		            turnOrder.setText("GAME OVER MAN");
		            score -= 20 * Level;

		            // Checks if the score is not null before clearing user guesses and creating a new sequence.
		            if(score != null){
		                seq.getUserGuessSequence().clear();
		                seq = new Sequence();
		                CurrentScore.setText("" + score);
		            }

		            // If the score is null, the user is encouraged to try again.
		            else {
		                turnOrder.setText("No high score... try again?");
		                seq.getUserGuessSequence().clear();
		                if(score > 0) {
		                    seq = new Sequence();
		                    CurrentScore.setText("" + score); 
		                } else {
		                    PlayBtn.setEnabled(true);
		                    score = 0;
		                    CurrentScore.setText("" + score);
		                    disableButtons(GreenLight, RedLight, BlueLight, YellowLight);
		                }
		            }
		        }
		        checkScore();
		    }
		});

		// Sets the button's default state to be opaque with no border and a dark green background.
		GreenLight.setOpaque(true);
		GreenLight.setBorderPainted(false);
		GreenLight.setBackground(new Color(0, 128, 0));
		gamePlane.setLayer(GreenLight, 2);
		GreenLight.setBounds(50, 69, 150, 152);
		gamePlane.add(GreenLight);

		// The blocks of code following this setup other buttons (RedLight, BlueLight, YellowLight) in a similar way.

		
		// This block creates a JButton "RedLight" and sets up its behavior on being clicked.
		RedLight = new JButton("");
		RedLight.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        // Changes the button's color to red and starts a timer.
		        RedLight.setBackground(Color.RED);
		        redTimer.stop();
		        redTimer.start();

		        // Checks if the user's guess ('R' for red) is correct.
		        if(seq.userInput('R') == true) {
		            // If the user's turn is over (they've made all their guesses for this round), they get a score increase.
		            if(seq.turnOver()) {
		                turnOrder.setText("Correct! Score Up!");
		                score += 10 * Level;
		          
		                Levelchecker(Levelpoint, CurrentScore);
		                CurrentScore.setText("" + score);
		                doNothing.start();
		                seq.getUserGuessSequence().clear();
		                nextTurn();
		            }

		            // If the turn isn't over, they're encouraged to continue guessing.
		            else {
		                turnOrder.setText("Go on...");
		            }
		        }

		        // If the user's guess is incorrect, they're told that the game is over, and their score is decreased.
		        else {
		            turnOrder.setText("GAME OVER MAN");
		            score -= 20 * Level;
		            // The error sound is played.
		            String ErrorLocation = "Audio/Error.wav";
		            try {
		                File ErrorFile = new File(ErrorLocation);
		                AudioInputStream ErrorAudioFile = AudioSystem.getAudioInputStream(ErrorFile);
		                Clip ErrorSound = AudioSystem.getClip();
		                ErrorSound.open(ErrorAudioFile);
		                ErrorSound.start();
		            } catch (Exception e1) {
		                JOptionPane.showMessageDialog(null, "Problem playing sound");
		            }

		            // Checks if the score is not null before clearing user guesses and creating a new sequence.
		            if(score != null) {
		                seq.getUserGuessSequence().clear();
		                seq = new Sequence();
		                CurrentScore.setText("" + score);
		            }

		            // If the score is null, the user is encouraged to try again.
		            else {
		                turnOrder.setText("No high score... try again?");
		                seq.getUserGuessSequence().clear();
		                if(score > 0) {
		                    seq = new Sequence();
		                    CurrentScore.setText("" + score); 
		                } else {
		                    PlayBtn.setEnabled(true);
		                    score = 0;
		                    CurrentScore.setText("" + score);
		                    disableButtons(GreenLight, RedLight, BlueLight, YellowLight);
		                }
		            }
		            checkScore();
		        }
		    }
		});

		// Sets the button's default state to be opaque with no border and a dark red background.
		RedLight.setOpaque(true);
		RedLight.setBorderPainted(false);
		RedLight.setBackground(new Color(139, 0, 0));
		gamePlane.setLayer(RedLight, 1);
		RedLight.setBounds(211, 69, 150, 152);
		gamePlane.add(RedLight);

		
		BlueLight = new JButton("");
		BlueLight.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        // Changes the button's background to a bright blue color and starts a timer
		        BlueLight.setBackground(brightBlue);
		        blueTimer.stop();
		        blueTimer.start();

		        // Checks if the user's guess ('B' for blue) is correct
		        if(seq.userInput('B') == true) {
		            // If the user's turn is over, they get a score increase
		            if(seq.turnOver()) {
		                turnOrder.setText("Correct! Score Up!");
		             
		                score += 10 * Level;
		                Levelchecker(Levelpoint, CurrentScore);
		                CurrentScore.setText("" + score);
		                doNothing.start();
		                seq.getUserGuessSequence().clear();
		                nextTurn();
		            }
		            // If the turn isn't over, they're encouraged to continue guessing
		            else {
		                turnOrder.setText("Go on...");
		            }
		        }
		        // If the user's guess is incorrect, they're told that the game is over
		        else {
		            turnOrder.setText("GAME OVER MAN");
		            score -= 20 * Level;
		            disableButtons(GreenLight, RedLight, BlueLight, YellowLight);
		            // Plays an error sound
		            String ErrorLocation = "Audio/Error.wav";
		            try {
		                File ErrorFile = new File(ErrorLocation);
		                AudioInputStream ErrorAudioFile = AudioSystem.getAudioInputStream(ErrorFile);
		                Clip ErrorSound = AudioSystem.getClip();
		                ErrorSound.open(ErrorAudioFile);
		                ErrorSound.start();
		            } catch (Exception e1) {
		                JOptionPane.showMessageDialog(null, "Problem playing sound");
		            }

		            // If score is not null, clears the user guess sequence, creates a new sequence, and updates the score
		            if(score != null) {
		                seq.getUserGuessSequence().clear();
		                seq = new Sequence();
		                CurrentScore.setText("" + score);
		            }
		            // If the score is null, the user is encouraged to try again
		            else {
		                turnOrder.setText("No high score... try again?");
		                seq.getUserGuessSequence().clear();
		                if(score > 0) {
		                    seq = new Sequence();
		                    CurrentScore.setText("" + score); 
		                } else {
		                    PlayBtn.setEnabled(true);
		                    score = 0;
		                    CurrentScore.setText("" + score);
		                    disableButtons(GreenLight, RedLight, BlueLight, YellowLight);
		                }
		            }
		            checkScore();
		        }
		    }
		});

		// Sets the button's default state to be opaque with no border and a blue background
		BlueLight.setOpaque(true);
		BlueLight.setBorderPainted(false);
		BlueLight.setBackground(new Color(0, 0, 205));
		gamePlane.setLayer(BlueLight, 2);
		BlueLight.setBounds(50, 233, 150, 146);
		gamePlane.add(BlueLight);
		
		// Creates a new JButton "YellowLight" and configures its behavior when clicked
		YellowLight = new JButton("");
		YellowLight.addActionListener(new ActionListener() {
		    public void actionPerformed(ActionEvent e) {
		        // Changes the button's background to yellow and starts a timer
		        YellowLight.setBackground(Color.YELLOW);
		        yellowTimer.stop();
		        yellowTimer.start();

		        // Checks if the user's guess ('Y' for yellow) is correct
		        if(seq.userInput('Y') == true) {
		            // If the user's turn is over, they get a score increase
		            if(seq.turnOver()) {
		                turnOrder.setText("Correct! Score Up!");
		               
		                score += 10 * Level;
		                Levelchecker(Levelpoint, CurrentScore);
		                CurrentScore.setText("" + score);
		                doNothing.start();
		                seq.getUserGuessSequence().clear();
		                nextTurn();
		            }
		            // If the turn isn't over, they're encouraged to continue guessing
		            else {
		                turnOrder.setText("Go on...");
		            }
		        }
		        // If the user's guess is incorrect, they're told that the game is over
		        else {
		            turnOrder.setText("GAME OVER MAN");
		            score -= 20 * Level;
		            // Plays an error sound
		            String ErrorLocation = "Audio/Error.wav";
		            try {
		                File ErrorFile = new File(ErrorLocation);
		                AudioInputStream ErrorAudioFile = AudioSystem.getAudioInputStream(ErrorFile);
		                Clip ErrorSound = AudioSystem.getClip();
		                ErrorSound.open(ErrorAudioFile);
		                ErrorSound.start();
		            } catch (Exception e1) {
		                JOptionPane.showMessageDialog(null, "Problem playing sound");
		            }

		            // If score is not null, clears the user guess sequence, creates a new sequence, and updates the score
		            if(score != null) {
		                seq.getUserGuessSequence().clear();
		                seq = new Sequence();
		                CurrentScore.setText("" + score);
		            }
		            // If the score is null, the user is encouraged to try again
		            else {
		                disableButtons(GreenLight, RedLight, BlueLight, YellowLight);
		                turnOrder.setText("No high score... try again?");
		                seq.getUserGuessSequence().clear();
		                if(score > 0) {
		                    seq = new Sequence();
		                    CurrentScore.setText("" + score); 
		                } else {
		                    PlayBtn.setEnabled(true);
		                    score = 0;
		                    CurrentScore.setText("" + score);
		                    disableButtons(GreenLight, RedLight, BlueLight, YellowLight);
		                }
		            }
		            checkScore();
		        }
		    }
		});

		// Sets the button's default state to be opaque with no border and a yellow background
		YellowLight.setOpaque(true);
		YellowLight.setBorderPainted(false);
		YellowLight.setBackground(new Color(204, 204, 0));
		gamePlane.setLayer(YellowLight, 2);
		YellowLight.setBounds(211, 233, 150, 146);
		gamePlane.add(YellowLight);
		
		
		

		//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		// Method				: 
		//
		// Method parameters	:  Game button and 
		//
		// Method return		:
		//
		// Synopsis				: Keeps track of button presses.
		//
		// Modifications		:
		//							Date			Developer			Notes
		//							----			---------			-----
		//							2023-05-15		A Dhruvit			None.
		//
		//=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		

		// Creates a new JButton "Game" with a black background and a specific icon
		JButton Game = new JButton("");
		Game.setBackground(Color.BLACK);
		gamePlane.setLayer(Game, 1);
		Game.setIcon(new ImageIcon(Matchgame1.class.getResource("/matchgame/Squares.PNG")));
		Game.setBounds(36, 59, 341, 334);
		gamePlane.add(Game);


            // Create a "Quit" menu item and add it to the gamePlane panel
		JMenuItem quitBtn = new JMenuItem("Quit");
		quitBtn.setBounds(221, 508, 156, 24);
		gamePlane.add(quitBtn);

		                                                                // Add an action listener to the Quit menu item that will exit the program when clicked
		quitBtn.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
		System.exit(0);
		}
		});

		GreenLight.setEnabled(false);
		RedLight.setEnabled(false);
		BlueLight.setEnabled(false);
		YellowLight.setEnabled(false);
		                                                                  // Set the horizontal text position of the Quit menu item to the center
		quitBtn.setHorizontalTextPosition(SwingConstants.CENTER);

		                                                                 // Set the horizontal alignment of the Quit menu item to the center
		quitBtn.setHorizontalAlignment(SwingConstants.CENTER);

		                                                                   // Set the font of the Quit menu item to "Dialog" with a bold size of 15
		quitBtn.setFont(new Font("Dialog", Font.BOLD, 15));

		                                                                    // Set the border of the Quit menu item to a raised bevel border with light gray and dark gray colors
		quitBtn.setBorder(new BevelBorder(BevelBorder.RAISED, null, null, Color.LIGHT_GRAY, Color.DARK_GRAY));

		                                                                    // Set the background color of the Quit menu item to yellow
		quitBtn.setBackground(Color.YELLOW);
		
	}
	
	protected void disableButtons(JButton GreenLight, JButton RedLight, JButton BlueLight, JButton YellowLight) {
		
		GreenLight.setEnabled(false);
		RedLight.setEnabled(false);
		BlueLight.setEnabled(false);
		YellowLight.setEnabled(false);
		
	}

	/**

	Increases the sequence by one, sets the text of turnOrder to "Next turn!", and starts the timer.
	*/
	public void nextTurn() {
	
	seq.Sequence(Level);
	turnOrder.setText("Next turn!");
	timer.start();
	}
	
	
}