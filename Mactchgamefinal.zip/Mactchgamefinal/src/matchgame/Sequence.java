package matchgame;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Sequence {
	
	

    // List to store the randomly generated color sequence
    private List<Character> generatedSequence = new ArrayList<>();

    // List to store the user's guess sequence
    private List<Character> userGuessSequence = new ArrayList<>();

    // Variable to store the score
    private int score = 0;

    // Array of characters representing four colors: yellow, blue, red, and green
    private char[] rgby = {'Y', 'B', 'R', 'G'};

    // Random number generator
    private Random rand = new Random();

    // Variable to store the current level
    private int Level;
    
    // Method to retrieve the generated sequence
    public List<Character> getSequence() {
        return generatedSequence;
    }

    // Default constructor that generates a sequence of 3 random colors
    public Sequence() {
        for(int i = 1; i < 4; i++) {
            generatedSequence.add(rgby[rand.nextInt(4)]);
        }
    }

    // Constructor that generates a sequence of random colors of length specified by the level parameter
    public void Sequence(int level) {
        this.Level = level;
        for(int i = 1; i < level; i++
        		 ) {
        	
            generatedSequence.add(rgby[rand.nextInt(4)]);
            Level++;}
        }
    

    // Method to clear the user's guess sequence and increase the level if the guess sequence has 4 characters
    

    // Method to add the user's guess to the guess sequence and check if it's correct
    public boolean userInput(char input) {
        userGuessSequence.add(input);
        if(generatedSequence.get(userGuessSequence.size()-1) == userGuessSequence.get(userGuessSequence.size()-1)) {
            return true;
        } else {
            return false;
        }
    }

    // Method to get the current score
    public int getCurrentScore() {
        return score;
    }

    // Method to get a character from the generated sequence at a specified position
    public char getSequenceChar(int n) {
        return generatedSequence.get(n);
    }

    // Method to get a character from the user's guess sequence at a specified position
    public char getUserChar(int n) {
        return generatedSequence.get(n);
    }

    // Method to get the user's guess sequence
    public List<Character> getUserGuessSequence() {
        return userGuessSequence;
    }

    // Method to check if the user's turn is over
    public boolean turnOver() {
        if(generatedSequence.size() == userGuessSequence.size()) {
            return true;
        } else {
            return false;
        }
    }

    // Method to pause the game for a specified number of milliseconds
    public void pause(int ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            System.out.println("Thread interrupted");
        }
    }
}


