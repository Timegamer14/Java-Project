import java.util.Scanner;

import static java.math.BigDecimal.ROUND_HALF_UP;

import java.math.BigDecimal;
import java.text.NumberFormat;



public class Sum {

	public static NumberFormat formatter;

	public static   void main(String[] args) {
		// TODO Auto-generated method stub
        
        //Amount of sale
        float amountofsale = 0;                                             // Amount of Sale Float decimal value
        //Amount of Tendered
        
       float amountoftendered = 0;                                     // Amount of Tendered Float decimal value
       //User input
        Scanner X = new Scanner(System.in);                          // User Input like use can keyboard input as final input
        //Change return
        System.out.println("Change Return");                      // Change Return Candaian Currency
       
        //Amount of sale input
        System.out.print("Amount of sale : $");                     // Amount Sale by User not more than 99
        try {
        	
      	  amountofsale = X.nextFloat();                              //Try and Catch error if a user put unvalid letter like  A,bc it will give error
      	  
        }
        catch(Exception error){
      	  System.out.println("Error!");                                       // user in put value
	      }
        
        
        
        System.out.print("Amount of Tendered : $");                           //Try and Catch error if a user put unvalid letter like  A,bc it will give error
        try {
        
      	    
      	  amountoftendered = X.nextFloat();                                      // user in put value
        }
        catch(Exception error){
      	  System.out.println("Error!");
        }
        /*
         * check if amount of sale value 0-99
         */
        /*Change return
         * AMOUNT OF SALE : $22.42
         * AMOUNT OF TENDERED : $50
         * CHANGE RETURN : $ 27.60
         * Tweinties = 1
         * Tens      = 0
         * Twos      = 3
         * Ones      = 1
         * Quaters   = 2
         * Dimes     = 1
         * Nickels   = 0
         */
        if(amountofsale > 0 && amountofsale <= 1000000)                                 //If amount of sale value will be 0 and 99
        {
        	//Amount of tendered is not greater than sale and not 
      	  if(amountoftendered >= amountofsale && amountoftendered <= 10000000)        //If amount of Tendered value will be 0 and 99
      	  {
      		//Changed return = Tendered - sale 
      		 
      	
	
      		double change = (double)((amountoftendered - amountofsale));              // double amount tendered - amount sale value will be in point
      		BigDecimal roundedAmount = new BigDecimal(change).setScale(2, BigDecimal.ROUND_HALF_UP); // Round up and down for penny 
      		 change = Math.round(change * 20) / 20.0;

             // Print the change
             System.out.printf("Change returned: $%.2f\n", change);           //
             
      		int changeInCents = (int) Math.round(change * 100);                         // Change *100 gives the value of in int

      		int twenties = (int) (change / 20);                               // change = 50/20 = 2.5 2 note of 20 will be given
            change = change % 20;

            int tens = (int) (change / 10);                                   //change = 50/10 = 5 5 note of 10 will be given
            change = change % 10;

            int fives = (int) (change / 5);                                    //change = 50/5 = 10 10 note of 5 will be given
            change = change % 5;

            int toonies = (int) (change / 2);                                  //change = 50/2 = 25 25 coins of 2 will be given
            change = change % 2;

            int loonies = (int) (change/1);                                          //change = 50/1 = 50 50 coins of 1 will be given
            change = change % 1;

            int quarters = (int) (change / 0.25);                                 //change = 0.75/0.25 = 3 3 coins of .25 will be given
            change = change % 0.25;

            int dimes = (int) (change / 0.10);                                     //change = 0.50/0.10 = 5 5 coins of 0.10 will be given
            change = change % 0.10;

            int nickels = (int) Math.round (change / 0.05);                                    //change = 0.10/.05 = 2 2 coins of 0.05 will be given

            change = change % 0.05;
			
             
          System.out.println("Twienties: " + twenties);                              // how much note will print of 20
          System.out.println("Tens: " + tens);                                       // how much note will print of 10
          System.out.println("Fives:"+ fives);                                       // how much note will print of 5
          System.out.println("Two: " + toonies);                                     // how much note will print of 2
          System.out.println("One: " + loonies);                                     // how much note will print of 1
          System.out.println("Quater: " + quarters);                                  // how much note will print of 0.25
          System.out.println("Dimes: " + dimes);                                      // how much note will print of 0.10
          System.out.println("Nickels: " + nickels);                                  // how much note will print of 0.05
                                                 
   
            
            
          return;
             
      	  }
      	  else{  
                                                                                        //Error because of amount tendered more than 1000000 
      		  System.out.println("Enter valid Tendered  " + amountoftendered);
      	  }
      	  
        }
        else {
        	                                                                    //Error because of amount sale more than 1000000
      	  System.out.println("Enter valid Sale  " + amountofsale);
        }
	
		
       
        
	}

}
