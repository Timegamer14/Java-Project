import javax.swing.*;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

//Suppress warnings related to serialization since we're not using it in this context.

public class Medium extends JFrame implements Serializable {
	 private static final long serialVersionUID = 1L;
 private JLabel lblGuess, scoreLabel, levelLabel, score1, level1, levelRangeLabel, track1AttemptsLabel,track2AttemptsLabel,track3AttemptsLabel,track4AttemptsLabel,track5AttemptsLabel,track6AttemptsLabel,track7AttemptsLabel;
 private JTextField track1, track2, track3, track4, track5;//Text Feild 1,2,3,4,5
 private JButton guessButton, nextLevelButton;//Button

 private JLabel guessIndicator1, guessIndicator2, guessIndicator3, guessIndicator4, guessIndicator5, guessLabel1, guessLabel2, guessLabel3, guessLabel4, guessLabel5, sign1, sign2, sign3, sign4, sign5;
 private JLabel playerNameLabel;//Player name label
 private ArrayList<Integer> guessedNumbers = new ArrayList<>();//guessed number 
 // Variables to track game state
 private int track1Attempts = 7;//Track attempts 1,2,3,4,5,6,7
 private int track2Attempts = 7;
 private int track3Attempts = 7;
 private int track4Attempts = 7;
 private int track5Attempts = 7;
 private int track6Attempts = 11;
 private int track7Attempts = 11;
 private int level = 1; // Start at level 1
 private int tracks = 5; // The number of tracks for medium level

 private int score; // Player's score
 private int bonusAttempts = 0; // Bonus attempts a player can earn
 private int currentTrack = 1; // Current track being guessed
 private int mode1, mode2, mode3, mode4, mode5; // Modes of the 5 tracks
 public static int[] numbers1 = new int[1000]; // Array to store numbers for the game
 public static int[] numbers2 = new int[1000]; // Array to store numbers for the game
 public static int[] numbers3 = new int[1000]; // Array to store numbers for the game
 public static int[] numbers4 = new int[1000]; // Array to store numbers for the game
 public static int[] numbers5 = new int[1000]; // Array to store numbers for the game
 public static int maxNumber = 100;
 // Lists to keep track of guessed and correctly guessed tracks
 private ArrayList<Integer> correctGuesses = new ArrayList<>();//Correct Guesses check
 private ArrayList<Integer> completedLevels = new ArrayList<>();//correct completed level
 private ArrayList<Integer> guessedTracks = new ArrayList<>();//how much guess is track
 private JLabel previousGuessLabel1;// previous guess label 1 2 3 45
 private JLabel previousGuessLabel2;
 private JLabel previousGuessLabel3;
 private JLabel previousGuessLabel4;
 private JLabel previousGuessLabel5;

 public static int[] numbers = new int[1000];
 private String initials;
 // Player profile
 private PlayerProfile userProfile;
 private String difficulty = "Medium";
 // Constructor
 public Medium(String initials ) {
	 this.initials = initials; // Initialize the user profile with the provided initials
     userProfile = new PlayerProfile(initials);
     currentTrack = 0;
     initialize(); // Initialize the GUI
     changeTrack();
     loadGameState();

     dispose();
    
 }
  
	private void initialize() {
		setTitle("Medium Level");
		setSize(800, 533);

		// add a window listener to save the game state when window is closing
		addWindowListener(new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		        // Call the method that saves the game state
		        saveGameState();
		        System.out.println("Game state saved.");
		    }
		});

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);
        
     // Creating and positioning all labels, buttons and text fields on the frame

        lblGuess = new JLabel("5");
        lblGuess.setBounds(601, 60, 112, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
     
        getContentPane().add(lblGuess);
        
        
        
        lblGuess = new JLabel("4");
        lblGuess.setBounds(495, 60, 112, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
     
        getContentPane().add(lblGuess);
        lblGuess = new JLabel("3");
        lblGuess.setBounds(389, 60, 112, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
     
        getContentPane().add(lblGuess);
        lblGuess = new JLabel("2");
        lblGuess.setBounds(292, 60, 112, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
     
        getContentPane().add(lblGuess);
        lblGuess = new JLabel("1");
        lblGuess.setBounds(180, 60, 51, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
     
        getContentPane().add(lblGuess);
        lblGuess = new JLabel("Guess Number");
        lblGuess.setBounds(10, 85, 112, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
     
        getContentPane().add(lblGuess);

        
        lblGuess = new JLabel("Guess Numbered");
        lblGuess.setBounds(10, 167, 137, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(lblGuess);
        
     
        
        lblGuess = new JLabel("Assist Arrow");
        lblGuess.setBounds(10, 126, 112, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(lblGuess);
        
        lblGuess = new JLabel("Previous Guess");
        lblGuess.setBounds(10, 235, 172, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(lblGuess);
        
        previousGuessLabel1 = new JLabel("");
        previousGuessLabel1.setBounds(471, 235, 72, 46);
        previousGuessLabel1.setFont(previousGuessLabel1.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(previousGuessLabel1);

        previousGuessLabel2 = new JLabel("");
        previousGuessLabel2.setBounds(277, 235, 72, 46);
        previousGuessLabel2.setFont(previousGuessLabel2.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(previousGuessLabel2);

        previousGuessLabel3 = new JLabel("");
        previousGuessLabel3.setBounds(359, 235, 72, 46);
        previousGuessLabel3.setFont(previousGuessLabel3.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(previousGuessLabel3);
        
        previousGuessLabel4 = new JLabel("");
        previousGuessLabel4.setBounds(153, 235, 72, 46);
        previousGuessLabel4.setFont(previousGuessLabel4.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(previousGuessLabel4);

        previousGuessLabel5 = new JLabel("");
        previousGuessLabel5.setBounds(574, 235, 72, 46);
        previousGuessLabel5.setFont(previousGuessLabel5.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(previousGuessLabel5);
        
        lblGuess = new JLabel("Match?");
        lblGuess.setBounds(10, 205, 172, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(lblGuess);
        
        lblGuess = new JLabel("Lives");
        lblGuess.setBounds(122, 306, 51, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(lblGuess);
     // sign1, sign2, sign3, sign4, sign5 are used to display the guess result signs, initially they are empty
        
        sign1 = new JLabel("");
        sign1.setBounds(471, 205, 72, 46);
        sign1.setFont(sign1.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(sign1);

        sign2 = new JLabel("");
        sign2.setBounds(267, 205, 72, 46);
        sign2.setFont(sign2.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(sign2);

        sign3 = new JLabel("");
        sign3.setBounds(359, 205, 72, 46);
        sign3.setFont(sign3.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(sign3);
        
        sign4 = new JLabel("");
        sign4.setBounds(153, 208, 72, 46);
        sign4.setFont(sign4.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(sign4);

        sign5 = new JLabel("");
        sign5.setBounds(574, 205, 72, 46);
        sign5.setFont(sign5.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(sign5);
        
     // guessLabel1, guessLabel2, guessLabel3, guessLabel4, guessLabel5 are used to display the guess result labels, initially they are empty
        
        guessLabel1 = new JLabel("");
        guessLabel1.setBounds(471, 167, 72, 46);
        guessLabel1.setFont(guessLabel1.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessLabel1);

        guessLabel2 = new JLabel("");
        guessLabel2.setBounds(267, 167, 72, 46);
        guessLabel2.setFont(guessLabel2.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessLabel2);

        guessLabel3 = new JLabel("");
        guessLabel3.setBounds(371, 167, 72, 46);
        guessLabel3.setFont(guessLabel3.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessLabel3);
        
        
        
        guessLabel4 = new JLabel("");
        guessLabel4.setBounds(159, 167, 72, 46);
        guessLabel4.setFont(guessLabel4.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessLabel4);

        guessLabel5 = new JLabel("");
        guessLabel5.setBounds(574, 167, 72, 46);
        guessLabel5.setFont(guessLabel5.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessLabel5);
        
        
        // guessIndicator1, guessIndicator2, guessIndicator3, guessIndicator4, guessIndicator5 are used to display the guessing indicators, initially they are empty

        guessIndicator1 = new JLabel("");
        guessIndicator1.setBounds(470, 126, 73, 32);
        guessIndicator1.setFont(guessIndicator1.getFont().deriveFont(Font.BOLD, 18f)); // Set the font to bold and size 16
        getContentPane().add(guessIndicator1);

        guessIndicator2 = new JLabel("");
        guessIndicator2.setBounds(268, 122, 71, 35);
        guessIndicator2.setFont(guessIndicator2.getFont().deriveFont(Font.BOLD, 18f)); // Set the font to bold and size 16
        getContentPane().add(guessIndicator2);

        guessIndicator3 = new JLabel("");
        guessIndicator3.setBounds(366, 127, 71, 31);
        guessIndicator3.setFont(guessIndicator3.getFont().deriveFont(Font.BOLD, 18f)); // Set the font to bold and size 16
        getContentPane().add(guessIndicator3);

        guessIndicator4 = new JLabel("");
        guessIndicator4.setBounds(154, 122, 71, 31);
        guessIndicator4.setFont(guessIndicator3.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessIndicator4);

        guessIndicator5 = new JLabel("");
        guessIndicator5.setBounds(574, 125, 71, 31);
        guessIndicator5.setFont(guessIndicator3.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessIndicator5);

        // track1, track2, track3, track4, track5 are the input fields for user's guesses

        track1 = new JTextField(5);
        track1.setBounds(470, 93, 73, 19);
        getContentPane().add(track1);

        track2 = new JTextField(5);
        track2.setBounds(268, 93, 71, 19);
        getContentPane().add(track2);

        track3 = new JTextField(5);
        track3.setBounds(366, 93, 71, 19);
        getContentPane().add(track3);

        track4 = new JTextField(5);
        track4.setBounds(154, 93, 71, 19);
        getContentPane().add(track4);

        track5 = new JTextField(5);
        track5.setBounds(574, 93, 71, 19);
        getContentPane().add(track5);
        // arrowLabel is used to provide instructions to the user

        JLabel arrowLabel = new JLabel("↑ means guess higher, ↓ means guess lower, ✓ Correct");
        arrowLabel.setBounds(106, 28, 529, 41);
        arrowLabel.setFont(arrowLabel.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(arrowLabel);
        // The table is used to display the tracks and guesses

        JLabel message = new JLabel("To Save game Closing tab Or Complete one level and click next Level");
        message.setBounds(100, 434, 662, 41);
        message.setFont(message.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(message);

        // Add the "Next Level" button
        nextLevelButton = new JButton("Next Level");
        nextLevelButton.setBounds(674, 140, 102, 41);
        getContentPane().add(nextLevelButton);
        nextLevelButton.setEnabled(false);
        nextLevelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	saveGameState();
            	changehigh ();
            	changeLevel();
                nextLevelButton.setEnabled(false);
                guessButton.setEnabled(true); 
            }
        });
        // guessButton is used to submit the user's guess

        guessButton = new JButton("Play");
        guessButton.setBounds(674, 97, 102, 41);
        getContentPane().add(guessButton);
        guessButton.setEnabled(true);
        guessButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkGuess();
            }
        });
      

        
       
        
     // Generating an array of 1000 random numbers, with the range dependent on the current level
        numbers = new int[1000];
        Random random = new Random();
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = random.nextInt(100 * level) + 1;
        }

        // Initializing the score label with initial score text
        scoreLabel = new JLabel("Score: ");
        scoreLabel.setBounds(12, 5, 92, 13);
        scoreLabel.setFont(scoreLabel.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 12
        getContentPane().add(scoreLabel);

        // Initializing the level label with initial level text
        levelLabel = new JLabel("Level: ");
        levelLabel.setBounds(114, 5, 84, 13);
        levelLabel.setFont(levelLabel.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 12
        getContentPane().add(levelLabel);
        loadGameState();
        // Displaying the current level 
        level1 = new JLabel("0");
        level1.setBounds(169, 4, 45, 13);
        level1.setFont(level1.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(level1);
        loadGameState();
        // Label to display the range of the current level
        levelRangeLabel = new JLabel("Range: 1 -" + maxNumber);
        levelRangeLabel.setBounds(193, -3, 115, 28);
        levelRangeLabel.setFont(levelRangeLabel.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 12
        getContentPane().add(levelRangeLabel);
        loadGameState();
        // Displaying the current score
        score1 = new JLabel(Integer.toString(score));
        score1.setBounds(67, 5, 45, 13);
        score1.setFont(score1.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(score1);
        loadGameState();
        // Label to display the name of the player
        playerNameLabel = new JLabel();
        playerNameLabel.setBounds(343, 5, 200, 13);
        playerNameLabel.setFont(playerNameLabel.getFont().deriveFont(Font.BOLD, 14f));
        getContentPane().add(playerNameLabel);
        updatePlayerNameLabel(); // Updating the name of the player in the label
        loadGameState();
        
     // Add labels for displaying the remaining attempts for each track
        track1AttemptsLabel = new JLabel(" " + track1Attempts);
        track1AttemptsLabel.setBounds(192, 317, 84, 13);
        getContentPane().add(track1AttemptsLabel);
        loadGameState();
        track2AttemptsLabel = new JLabel(" " + track2Attempts);
        track2AttemptsLabel.setBounds(292, 317, 84, 13);
        getContentPane().add(track2AttemptsLabel);
        loadGameState();
        track3AttemptsLabel = new JLabel(" " + track3Attempts);
        track3AttemptsLabel.setBounds(389, 317, 84, 13);
        getContentPane().add(track3AttemptsLabel);
        loadGameState();
        track4AttemptsLabel = new JLabel(" " + track4Attempts);
        track4AttemptsLabel.setBounds(495, 317, 84, 13);
        getContentPane().add(track4AttemptsLabel);
        loadGameState();
        track5AttemptsLabel = new JLabel(" " + track5Attempts);
        track5AttemptsLabel.setBounds(601, 317, 84, 13);
        getContentPane().add(track5AttemptsLabel);

        loadGameState();
     
        // Updating the label for level
        updateLevelLabel();
        loadGameState();

        // Setting up the background image for the GUI
        ImageIcon backgroundImageIcon = new ImageIcon("Media/bg.png");
        JLabel backgroundLabel = new JLabel(backgroundImageIcon);
        backgroundLabel.setBounds(0, 0, 800, 522);
        getContentPane().add(backgroundLabel); // Add the background label to the content pane

    }
	 // This method saves the game state to a file
    private void saveGameState() {
        try (PrintWriter out = new PrintWriter(new FileOutputStream(initials + "_gamestate.txt"))) {
            out.println(score);
            out.println(level);
            out.println(difficulty);  // Save the difficulty to the file
            
            out.println(track1Attempts);
            out.println(track2Attempts);
            out.println(track3Attempts);
            out.println(track4Attempts);
            out.println(track5Attempts);
            out.println(track6Attempts);
            out.println(track7Attempts);
            out.println(maxNumber);

            System.out.println("Game state saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving game state: " + e.getMessage());
        }
    }
    // This method loads the game state from a file
    private void loadGameState() {
        try (Scanner scanner = new Scanner(new FileInputStream(initials + "_gamestate.txt"))) {
            score = scanner.nextInt();
            level = scanner.nextInt();
            difficulty = scanner.next();  // Load the difficulty from the file
            track1Attempts = scanner.nextInt();
            track2Attempts = scanner.nextInt();
            track3Attempts = scanner.nextInt();
            track4Attempts = scanner.nextInt();
            track5Attempts = scanner.nextInt();
            track6Attempts = scanner.nextInt();
            track7Attempts = scanner.nextInt();
  
            maxNumber = scanner.nextInt();

            System.out.println("Game state loaded successfully.");
        } catch (IOException e) {
            System.out.println("Error loading game state: " + e.getMessage());
        }
    }
  //Change the difficulty level
    private void changeDifficulty(String newDifficulty) {
      difficulty = newDifficulty;
    }
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                : Generate number
    //
    // Method parameters    :For easy from 1-1000
    //
    // Method return        :Mode 
    //
    // Synopsis                : check all three methods 
    //
    // Modifications        :
    //                            Date            Developer            Notes
    //                            5/6/23            Dhruvit            
    //
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
   
 // This function is used to generate modes for the game based on the current level
	// Method to generate mode for each track
	private void generateMode() {
	    // Initialize the array of numbers
	    numbers1 = new int[1000];
	    numbers2 = new int[1000];
	    numbers3 = new int[1000];
	    numbers4 = new int[1000];
	    numbers5 = new int[1000];
	    
	    Random random = new Random();
	    int minNumber = 1;
	    int maxNumber = 100 * level;
	    String levelRange = minNumber + " - " + maxNumber;

	    do {
	        generateNumbers(numbers1, random, minNumber, maxNumber);
	        generateNumbers(numbers2, random, minNumber, maxNumber);
	        generateNumbers(numbers3, random, minNumber, maxNumber);
	        generateNumbers(numbers4, random, minNumber, maxNumber);
	        generateNumbers(numbers5, random, minNumber, maxNumber);
	        // Generate random numbers for the three arrays and find their modes
            // Repeat until we have unique modes for each array
	        mode1 = findMode(numbers1);
	        mode2 = findMode(numbers2);
	        mode3 = findMode(numbers3);
	        mode4 = findMode(numbers4);
	        mode5 = findMode(numbers5);
	    } while (hasMultipleModes(mode1, mode2, mode3,mode4,mode5));

	}
	 // This method populates an array with random numbers within a given range
	private void generateNumbers(int[] numbers, Random random, int minNumber, int maxNumber) {
	    for (int i = 0; i < 1000; i++) {
	        numbers[i] = random.nextInt(maxNumber - minNumber + 1) + minNumber;
	    }
	}
	 // This method finds the mode (most frequent number) in an array
	private int findMode(int[] numbers) {
	    int element = 0;
	    int count = 0;

	    for (int j = 0; j < numbers.length; j++) {
	        int tempElement = numbers[j];
	        int tempCount = 0;

	        for (int p = 0; p < numbers.length; p++) {
	            if (numbers[p] == tempElement) {
	                tempCount++;
	            }
	        }

	        if (tempCount > count) {
	            element = tempElement;
	            count = tempCount;
	        }
	    }

	    return element;
	}
	 // This method checks if there are multiple identical modes among FIve given modes
	private boolean hasMultipleModes(int mode1, int mode2, int mode3, int mode4, int mode5) {
	    return (mode1 == mode2 && mode1 != mode3 && mode1 != mode4 && mode1 != mode5)
	        || (mode1 == mode3 && mode1 != mode2 && mode1 != mode4 && mode1 != mode5)
	        || (mode1 == mode4 && mode1 != mode2 && mode1 != mode3 && mode1 != mode5)
	        || (mode1 == mode5 && mode1 != mode2 && mode1 != mode3 && mode1 != mode4)
	        || (mode2 == mode3 && mode2 != mode1 && mode2 != mode4 && mode2 != mode5)
	        || (mode2 == mode4 && mode2 != mode1 && mode2 != mode3 && mode2 != mode5)
	        || (mode2 == mode5 && mode2 != mode1 && mode2 != mode3 && mode2 != mode4)
	        || (mode3 == mode4 && mode3 != mode1 && mode3 != mode2 && mode3 != mode5)
	        || (mode3 == mode5 && mode3 != mode1 && mode3 != mode2 && mode3 != mode4)
	        || (mode4 == mode5 && mode4 != mode1 && mode4 != mode2 && mode4 != mode3);
	}
	

    // This function is used to update the level label to display the current level
    private void updateLevelLabel() {
        level1.setText(String.valueOf(level));
    }

    // This function is used to update the score label to display the current score
    private void updateScoreLabel() {
        score1.setText(String.valueOf(score));
    }

    // This method is responsible for transitioning the game to the next level
    private void changeLevel() {
        // Increase the level count by 1
        level++;

        // Add the remaining attempts from the current level and any bonus attempts to the total attempts for the next level
        track1Attempts += (7 + bonusAttempts);
        track2Attempts += (7 + bonusAttempts);
        track3Attempts += (7 + bonusAttempts);
        track4Attempts += (7 + bonusAttempts);
        track5Attempts += (7 + bonusAttempts);
        bonusAttempts = 0;
        // Clear the text fields for each track
        track1.setText("");
        track2.setText("");
        track3.setText("");
        track4.setText("");
        track5.setText("");

        // Enable the text fields for each track
        track1.setEnabled(true);
        track2.setEnabled(true);
        track3.setEnabled(true);
        track4.setEnabled(true);
        track5.setEnabled(true);

        // Clear the guess indicators for each track
        guessIndicator1.setText("");
        guessIndicator2.setText("");
        guessIndicator3.setText("");
        guessIndicator4.setText("");
        guessIndicator5.setText("");
        // Clear the Prevoius indicators for each track
        previousGuessLabel1.setText("");
        previousGuessLabel2.setText("");
        previousGuessLabel3.setText("");
        previousGuessLabel4.setText("");
        previousGuessLabel5.setText("");
       
        // Set the focus to the first track input field
        track1.requestFocus();

        // Update the label that shows the current number of attempts
     // Update the remaining track attempts labels
        track1AttemptsLabel.setText("" + track1Attempts);
        track2AttemptsLabel.setText("" + track2Attempts);
        track3AttemptsLabel.setText("" + track3Attempts);
        track4AttemptsLabel.setText("" + track4Attempts);
        track5AttemptsLabel.setText("" + track5Attempts);
        if (level >= 1 && level <= 10) {
            maxNumber = level * 100;
        }
        levelRangeLabel.setText("Range: 1 - " + maxNumber);

        // Call a method to update the display of the current level
        updateLevelLabel();
     // Clear the list of guessed numbers
        guessedNumbers.clear();
        // Call a method to generate the new mode for the next level
        generateMode();

        // Clear the correct guesses from the last level
        correctGuesses.clear();

        // Call a method to update the score display
        updateScoreLabel(); 
      
           
    }
    private void changehigh ()
    {
    	if (maxNumber ==900 && level ==9) {
    	 dispose();  // Call dispose() on the instance of Easy
         high hard = new high(initials);
         hard.setVisible(true);
    	}
        
 	 
    }

    private void updatePlayerNameLabel() {
        playerNameLabel.setText("Player: " + userProfile.getPlayerName());
    }
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                :  Check guess check attempts and score and tracks
    //
    // Method parameters    :to check every tracks and attmepts and score
    //
    // Method return        :
    //
    // Synopsis                : 
    //
    // Modifications        :
    //                            Date            Developer            Notes
    //                            5/6/23            Dhruvit            
    //
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	private void checkGuess() {
	    // If the user is out of attempts, show a message
	    if (( track1Attempts == 0) ||
	            ( track2Attempts == 0) ||
	            ( track3Attempts == 0)||
	            ( track4Attempts == 0)||
	            ( track5Attempts == 0)
	            ) {
	        JOptionPane.showMessageDialog(this, "Out of attempts for this track");
	        userProfile.setScore(score);  // Save the score to the user's profile
	        // Ask the user if they want to restart the game
	        int option = JOptionPane.showConfirmDialog(this, "Game Over! Do you want to restart the game?", "Game Over", JOptionPane.YES_NO_OPTION);
	        // If the user wants to restart, call the restartGame method
	        if (option == JOptionPane.YES_OPTION) {
	            restartGame();
	        } else {
	            // If the user does not want to restart, close the application
	            System.exit(0);
	        }
	        return;
	    }

	    
	    
	    
	    // Initialize all guess variables
	    int guess1, guess2, guess3, guess4, guess5;

	    // Attempt to parse the text from each JTextField into an integer
	    try {
	        guess1 = Integer.parseInt(track1.getText());
	        guess2 = Integer.parseInt(track2.getText());
	        guess3 = Integer.parseInt(track3.getText());
	        guess4 = Integer.parseInt(track4.getText());
	        guess5 = Integer.parseInt(track5.getText());
	        
	      
	    } catch (NumberFormatException e) {
	        // If the text cannot be parsed into an integer, show an error message
	        JOptionPane.showMessageDialog(this, "Invalid input. Please enter a number.");
	        return;
	    }
	 
        
        
	    if (guess1 < 1 || guess1 > maxNumber || guess2 < 1 || guess2 > maxNumber || guess3 < 1 || guess3 > maxNumber|| guess4 > maxNumber || guess4 < 1 || guess5 > maxNumber|| guess5 < 1) {
            JOptionPane.showMessageDialog(this, "Invalid guess. Please enter a number between 1 and " + maxNumber + ".");
            return;
        }
        
	    // Assume that all guesses are correct until proven otherwise
	    boolean allCorrect = true;

	    // For track 1
	    if (guess1 != mode1 && !guessedTracks.contains(1)) {
	        allCorrect = false;  // Mark that not all guesses are correct
	        if (guess1 < mode1) {  // If the guess is lower than the mode
	            guessIndicator1.setText("↑‘");  // Set the indicator to show guess needs to be higher
	            sign1.setText("X");  // Mark this guess as incorrect
	        } else {  // If the guess is higher than the mode
	            sign1.setText("X");  // Mark this guess as incorrect
	            guessIndicator1.setText("↓");  // Set the indicator to show guess needs to be lower
	        }
	        track1Attempts--;
	    } else {  // If the guess is correct or has been guessed before

	        guessedTracks.add(1);  // Add this track to the set of guessed tracks
	        sign1.setText("✓");  // Mark this guess as correct
	        track1.setEnabled(false);  // Disable the input for this track as it has been correctly guessed
	        guessIndicator1.setEnabled(false);  // Disable the guess indicator for this track
	        if (!correctGuesses.contains(1)) {  // If this track hasn't been correctly guessed before
	        	int spareGuesses = track1Attempts;

	              while(spareGuesses > 0) {
	                if (spareGuesses >= 3) {
	                    score += 50; // Bonus points for guessing in 3 attempts or less
	spareGuesses -= 3;
	                }
	                else {
	                     score += 10 * spareGuesses;
	spareGuesses -= 1;
	                } 
                userProfile.setScore(score); // Add 10 points for a correct guess
	            correctGuesses.add(1);  // Add this track to the set of correctly guessed tracks
	        }
	    }
	}
	    // Repeat the same process for each track. Replace "1" with "2", "3", "4", "5", "6", "7" for the corresponding tracks.

	        if (guess2 != mode2 && !guessedTracks.contains(2)) {
	            allCorrect = false;
	            if (guess2 < mode2) {
	                guessIndicator2.setText("↑");
	                sign2.setText("X");
	            } else {
	                guessIndicator2.setText("↓");
	                sign2.setText("X");
	            }
	            track2Attempts--;
	        } else {
	            
	            guessedTracks.add(2);
	            sign2.setText("✓");
	            track2.setEnabled(false);
	            guessIndicator2.setEnabled(false);
	            if (!correctGuesses.contains(2)) {
	            	int spareGuesses = track2Attempts;

	                while(spareGuesses > 0) {
	                  if (spareGuesses >= 3) {
	                      score += 50; // Bonus points for guessing in 3 attempts or less
	  spareGuesses -= 3;
	                  }
	                  else {
	                       score += 10 * spareGuesses;
	  spareGuesses -= 1;
	                  }  userProfile.setScore(score);// Add 10 points for a correct guess on track 5
	                correctGuesses.add(2);
	            }
	        }
	        }
	        if (guess3 != mode3 && !guessedTracks.contains(3)) {
	            allCorrect = false;
	            if (guess3 < mode3) {
	                guessIndicator3.setText("↑");
	                sign3.setText("X");
	            } else {
	                guessIndicator3.setText("↓");
	                sign3.setText("X");
	            }
	            track3Attempts--;
	        } else {
	            
	            guessedTracks.add(3);
	            sign3.setText("✓");
	            track3.setEnabled(false);
	            guessIndicator3.setEnabled(false);
	            if (!correctGuesses.contains(3)) {
	            	int spareGuesses = track3Attempts;

	                while(spareGuesses > 0) {
	                  if (spareGuesses >= 3) {
	                      score += 50; // Bonus points for guessing in 3 attempts or less
	  spareGuesses -= 3;
	                  }
	                  else {
	                       score += 10 * spareGuesses;
	  spareGuesses -= 1;
	                  }  userProfile.setScore(score);// Add 10 points for a correct guess on track 5
	                correctGuesses.add(3);
	            }
	        }
	        }
	        if (guess4 != mode4 && !guessedTracks.contains(4)) {
	            allCorrect = false;
	            if (guess4 < mode4) {
	                guessIndicator4.setText("↑");
	                sign4.setText("X");
	            } else {
	                guessIndicator4.setText("↓");
	                sign4.setText("X");
	            }
	            track4Attempts--;
	        } else {
	         
	            guessedTracks.add(4);
	            sign4.setText("✓");
	            track4.setEnabled(false);
	            guessIndicator4.setEnabled(false);
	            if (!correctGuesses.contains(4)) {
	            	int spareGuesses = track4Attempts;

	                while(spareGuesses > 0) {
	                  if (spareGuesses >= 3) {
	                      score += 50; // Bonus points for guessing in 3 attempts or less
	  spareGuesses -= 3;
	                  }
	                  else {
	                       score += 10 * spareGuesses;
	  spareGuesses -= 1;
	                  }  userProfile.setScore(score);// Add 10 points for a correct guess on track 5
	                correctGuesses.add(4);
	            }
	        }
	        }
	        if (guess5 != mode5 && !guessedTracks.contains(5)) {
	            allCorrect = false;
	            if (guess5 < mode5) {
	                guessIndicator5.setText("↑");
	                sign5.setText("X");
	                
	            } else {
	                guessIndicator5.setText("↓");
	                sign5.setText("X");
	            }
	            track5Attempts--;
	        } else {
	         
	            guessedTracks.add(5);
	           sign5.setText("✓");
	            track5.setEnabled(false);
	            guessIndicator5.setEnabled(false);
	            if (!correctGuesses.contains(5)) {
	            	int spareGuesses = track5Attempts;

	                while(spareGuesses > 0) {
	                  if (spareGuesses >= 3) {
	                      score += 50; // Bonus points for guessing in 3 attempts or less
	  spareGuesses -= 3;
	                  }
	                  else {
	                       score += 10 * spareGuesses;
	  spareGuesses -= 1;
	                  }   userProfile.setScore(score);// Add 10 points for a correct guess on track 5
	                correctGuesses.add(5);
	            }
	        }
	}

	     // If all the guesses are correct
	        if (allCorrect) {
	            // Add the number of rows in the guess table to the correct guesses set

	            
	            // If all tracks have been guessed correctly
	            if (correctGuesses.size() == tracks) {
	                // Show a dialog message that the level is completed and move to the next level
	                JOptionPane.showMessageDialog(this, "Level completed! Moving to next level...");
	                // Update the attempts label
	                nextLevelButton.setEnabled(true);
	             // Disable the guess button
	                guessButton.setEnabled(false);
	                // Calculate and add bonus points for remaining guesses
	              
	                // Update user profile with the new score
	                userProfile.setScore(score);
	                
	                // Reset the attempts for the next level
	              
	                // Proceed to the next track
	                changeTrack();
	            } else {
	            	
	                // Not all tracks have been guessed correctly
	                // Display a message to user to guess remaining tracks
	                JOptionPane.showMessageDialog(this, "Correct! Guess the remaining tracks...");
	              
	                track1AttemptsLabel.setText("" + track1Attempts);
	                track2AttemptsLabel.setText("" + track2Attempts);
	                track3AttemptsLabel.setText("" + track3Attempts);
	                track4AttemptsLabel.setText("" + track4Attempts);
	                track5AttemptsLabel.setText("" + track5Attempts);
	                
	               

	                // Clear the input fields and enable them for the next round of guesses
	                track1.setText("");
	                track2.setText("");
	                track3.setText("");
	                track4.setText("");
	                track5.setText("");
	               
	               
	                track1.setEnabled(true);
	                track2.setEnabled(true);
	                track3.setEnabled(true);
	                track4.setEnabled(true);
	                track5.setEnabled(true);
	              

	                // Clear the guess indicators
	                guessIndicator1.setText("");
	                guessIndicator2.setText("");
	                guessIndicator3.setText("");
	                guessIndicator4.setText("");
	                guessIndicator5.setText("");
	                

	                // Set focus to the first track input field
	                track1.requestFocus();
	                // Update the attempts label
	                nextLevelButton.setEnabled(true);
	             // Disable the guess button
	                guessButton.setEnabled(false);
	                
	            }
	        } else {
	        	
	            	
	                // If not all the player's guesses are correct, decrement the number of attempts
	               // If there are no attempts left
	            	if (track1Attempts == 0 && track2Attempts == 0 && track3Attempts == 0&& track4Attempts == 0 && track5Attempts == 0 ) {
	                    JOptionPane.showMessageDialog(this, "Out of attempts for all tracks!");
	                    userProfile.setScore(score); // Save the score to the user's profile
	                    int option = JOptionPane.showConfirmDialog(this, "Game Over! Do you want to restart the game?", "Game Over", JOptionPane.YES_NO_OPTION);
	                    if (option == JOptionPane.YES_OPTION) {
	                        restartGame();
	                    } else {
	                        System.exit(0);
	                    }
	                    return;
	                
	                }
	            }

	        // Display the guesses in their respective labels
	        guessLabel1.setText(Integer.toString(guess1));
	        guessLabel2.setText(Integer.toString(guess2));
	        guessLabel3.setText(Integer.toString(guess3));
	        guessLabel4.setText(Integer.toString(guess4));
	        guessLabel5.setText(Integer.toString(guess5));
	       
	      

	        // Update the attempts label
	     // Update the attempts labels after each guess
	        track1AttemptsLabel.setText("" + track1Attempts);
	        track2AttemptsLabel.setText("" + track2Attempts);
	        track3AttemptsLabel.setText("" + track3Attempts);
	        track4AttemptsLabel.setText("" + track4Attempts);
	        track5AttemptsLabel.setText("" + track5Attempts);
	        
	        
	     // Display previous guesses in the labels
	        previousGuessLabel1.setText(Integer.toString(guess1));
	        previousGuessLabel2.setText(Integer.toString(guess2));
	        previousGuessLabel3.setText(Integer.toString(guess3));
	        previousGuessLabel4.setText(Integer.toString(guess4));
	        previousGuessLabel5.setText(Integer.toString(guess5));
	        // Clear the set of guessed tracks
	        guessedTracks.clear();

	        // Update the score label
	        updateScoreLabel();
	    }
    // This method restarts the game by resetting all the relevant variables and the GUI components
    private void restartGame() {
    	
        // Resets the score to 0
        score = 0;
        
        // Resets the level to the first level
        level = 1;

        // Resets the number of attempts to 7
        track1Attempts = 7;
        track2Attempts = 7;
        track3Attempts = 7;
        track4Attempts = 7;
        track5Attempts = 7;
        
        track1AttemptsLabel.setText("" + track1Attempts);
        track2AttemptsLabel.setText("" + track2Attempts);
        track3AttemptsLabel.setText("" + track3Attempts);
        track4AttemptsLabel.setText("" + track4Attempts);
        track5AttemptsLabel.setText("" + track5Attempts);

        // Resets the bonus attempts to 0
        bonusAttempts = 0;

        // Resets the current track to the first track
        currentTrack = 1;

        // Clears the correct guesses from the previous game
        correctGuesses.clear();

        // Clears the completed levels from the previous game
        completedLevels.clear();

        // Clears the guessed tracks from the previous game
        guessedTracks.clear();

        // Clears the text fields for each of the tracks
        track1.setText("");
        track2.setText("");
        track3.setText("");
        track4.setText("");
        track5.setText("");

        // Enables the text fields for each of the tracks
        track1.setEnabled(true);
        track2.setEnabled(true);
        track3.setEnabled(true);
        track4.setEnabled(true);
        track5.setEnabled(true);

        // Clears the guess indicators for each of the tracks
        guessIndicator1.setText("");
        guessIndicator2.setText("");
        guessIndicator3.setText("");
        guessIndicator4.setText("");
        guessIndicator5.setText("");

        previousGuessLabel1.setText("");
        previousGuessLabel2.setText("");
        previousGuessLabel3.setText("");
        previousGuessLabel4.setText("");
        previousGuessLabel5.setText("");
       
        // Updates the score label with the reset score
        updateScoreLabel();

        // Updates the level label with the reset level
        updateLevelLabel();

        // Generates the game mode for the new game
        generateMode();
        if (level >= 1 && level <= 9) {
            maxNumber = level * 100;
        }
        levelRangeLabel.setText("Range: 1 - " + maxNumber);
        // Sets the focus to the first track
        track1.requestFocus();
    }
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                :  Track and level is inset in this to complete all track add bonus attempts 
    //
    // Method parameters    :Store bonus attempts 
    //
    // Method return        :
    //
    // Synopsis                : 
    //
    // Modifications        :
    //                            Date            Developer            Notes
    //                            5/6/23            Dhruvit            
    //
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

    // This method handles the change of track. It updates the level if all tracks have been
    // completed, resets the state for the new track, and updates the interface.
    private void changeTrack() {

        // An array holding the JTextField objects for each track
        JTextField[] totalTracks = {track1, track2, track3, track4, track5};

        // Total number of levels in the game
        int totalLevels = 9;

        // If the current track is less than the total number of tracks, increment the current track
        if (currentTrack < totalTracks.length) {
            currentTrack++;
        } else {
            // Otherwise, if the level is less than the total number of levels, increment the level
            // and reset the current track to 1
            if (level < totalLevels) {
                level++;
                currentTrack = 1;

                // Add the completed level to the user's profile
                userProfile.addCompletedLevels(level);

                // Update the level label on the interface
                updateLevelLabel();
            } else {
                // If all levels have been completed, show a congratulations message, display the game
                // over message, and return from the method
                JOptionPane.showMessageDialog(this, "Congratulations! You've finished all the levels.");
                showGameOverMessage();
                return;
            }
        }

        // If the number of completed levels is equal to the total number of levels, the game has been 
        // completed, so show a congratulations message, display the game over message, and return from the method
        if (completedLevels.size() == totalLevels) {
            JOptionPane.showMessageDialog(this, "Congratulations! You've finished all the levels.");
            showGameOverMessage();
            return;
        }

        // Loop over each track JTextField in totalTracks, enable it, and clear its text
        for (JTextField totalTrack : totalTracks) {
            totalTrack.setEnabled(true);
            totalTrack.setText(""); // Clear the text fields
        }

        // Enable guess indicators and clear their text
        guessIndicator1.setEnabled(true);
        guessIndicator2.setEnabled(true);
        guessIndicator3.setEnabled(true);
        guessIndicator4.setEnabled(true);
        guessIndicator5.setEnabled(true);

        // Generate the modes for the next level or track
        generateMode();

        // Clear the text of the guess indicators
        guessIndicator1.setText("");
        guessIndicator2.setText("");
        guessIndicator3.setText("");
        guessIndicator4.setText("");
        guessIndicator5.setText("");
     // Clear the previous guess labels
        previousGuessLabel1.setText("");
        previousGuessLabel2.setText("");
        previousGuessLabel3.setText("");
        previousGuessLabel4.setText("");
        previousGuessLabel5.setText("");
        // Set the focus to the first track
        track1.requestFocus();

        // Reset the table model to 2 columns

        // Clear the list of guessed numbers
        guessedNumbers.clear();

        // Clear the table

        // Update the score in the user's profile
        userProfile.setScore(score);

        // If there are no attempts left, reset attempts to 7
        if (track1Attempts  <= 0) {
        	track1Attempts  =7; // Reset attempts only when no attempts are remaining
        }
        if (track2Attempts  <= 0) {
        	track2Attempts  = 7; // Reset attempts only when no attempts are remaining
        }
        if (track3Attempts  <= 0) {
        	track3Attempts  = 7; // Reset attempts only when no attempts are remaining
        }
        if (track4Attempts  <= 0) {
        	track4Attempts  = 7; // Reset attempts only when no attempts are remaining
        }
        if (track5Attempts  <= 0) {
        	track5Attempts  = 7; // Reset attempts only when no attempts are remaining
        }

        // Clear the correct guesses list
        correctGuesses.clear();
        // Remove all rows from the table model
        

        // Update the level label on the interface
        updateLevelLabel();
    }


    // This method shows a game over message when the game ends.
    private void showGameOverMessage() {
        // Create a string to hold the message. Start it with "Game Over!\n".
        String message = "Game Over!\n";

        // Add the player's name to the message string.
        message += "Player: " + userProfile.getPlayerName() + "\n";

        // Add the player's score to the message string.
        message += "Score: " + userProfile.getScore() + "\n";
        message += "Level"+level+"\n";
        // Note: This method currently doesn't actually show the message anywhere.
        // It creates the message string, but then doesn't do anything with it.
        // To show the message, you could use something like JOptionPane.showMessageDialog(null, message);
    }


}
