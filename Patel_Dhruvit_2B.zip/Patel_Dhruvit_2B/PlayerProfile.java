import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.Serializable;


@SuppressWarnings("serial")
public class PlayerProfile implements Serializable {
    private String playerName; // Player name
    private int score; // Score data
    private int level;// Level data
    private ArrayList<Integer> completedLevels; // Levels completed
    private static final int EASY = 1; // easy 1	
    	
    private static final int MODERATE = 2; // medium 2
    private static final int HARD = 3; //hard 3

    private int difficulty; // as intiger
    private transient JFrame swing; //frame
    private transient JButton easy, moderate, hard; //button
    private transient JLabel label, label_1; // label
 // Constructor for PlayerProfile
    
    public PlayerProfile(String playerName) { // Player data will be store and return in above lines
        this.playerName = playerName;
        this.score = 0;
        this.level = 0;
        this.completedLevels = new ArrayList<>();
    }
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                :  Player's name, score and level , completed level is stored
    //
    // Method parameters    :Store data from easy medium and hard
    //
    // Method return        :all the data is return
    //
    // Synopsis                : 
    //
    // Modifications        :
    //                            Date            Developer            Notes
    //                            5/6/23            Dhruvit            
    //
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
 // Getter and Setter methods for Player's name, score and level
   
    public String getPlayerName() {
        return playerName;
    }

   
    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

   
    public int getScore() {
        return score;
    }

   
    public void setScore(int score) {
        this.score = score;
    }

   
    public int getLevel() {
        return level;
    }

   
    public void setLevel(int level) {
        this.level = level;
    }
    // Method to add completed level to the list
    
    public ArrayList<Integer> getCompletedLevels() {
        return new ArrayList<>(completedLevels);
    }

    public void addCompletedLevels(int level) {
        this.completedLevels.add(level);
    }
    public void setDifficulty(int difficulty) {
        this.difficulty = difficulty;
    }

    // Method to get difficulty
    public int getDifficulty() {
        return difficulty;
    }
    private void prepareGUI() {
    	 // Set up fonts, frame, labels, buttons, and action listeners
        Font myFont = new Font("Times New Roman", Font.BOLD, 20);
        Font myFont1 = new Font("ROG Fonts", Font.BOLD, 20);

        swing = new JFrame("NumberCruncher");
        swing.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        swing.setSize(800, 522);

        Container pane = swing.getContentPane();
        swing.getContentPane().setLayout(null);

        label = new JLabel("Welcome to Number Cruncher");
        label.setBounds(178, 10, 463, 62);
        pane.add(label);

        label_1 = new JLabel("STAGES");
        label_1.setBounds(349, 64, 98, 40);
        pane.add(label_1);
        
        //Button for Easy Medium And Hard
        easy = new JButton("EASY");
        easy.setBounds(307, 125, 178, 40);
        easy.addActionListener(new DifficultyButtonListener(EASY));
        pane.add(easy);
      //Button Medium
        moderate = new JButton("MODERATE");
        moderate.setBounds(307, 175, 178, 40);
        moderate.addActionListener(new DifficultyButtonListener(MODERATE));
        pane.add(moderate);
//Button hard
        hard = new JButton("HARD");
        hard.setBounds(307, 225, 178, 40);
        hard.addActionListener(new DifficultyButtonListener(HARD));
        pane.add(hard);
                  //Image
        ImageIcon backgroundImageIcon = new ImageIcon("Media/bg.png");
        JLabel backgroundLabel = new JLabel(backgroundImageIcon);
        backgroundLabel.setBounds(0, 0, 800, 522);
        pane.add(backgroundLabel);
        
        

        label_1.setFont(myFont);
        label.setFont(myFont1);
        easy.setFont(myFont);
        moderate.setFont(myFont);
        hard.setFont(myFont);

        swing.setVisible(true);
    }
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                : Load and Save txt file
    //
    // Method parameters    :Name is saved and load in this with level Easy medium Hard
    //
    // Method return        :Name and level
    //
    // Synopsis                : 
    //
    // Modifications        :
    //                            Date            Developer            Notes
    //                            5/6/23            Dhruvit            
    //
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

    // Method to save game state txt
    public void saveGameState() {
        try (BufferedWriter out = new BufferedWriter(new FileWriter("gamestate.txt"))) {
            out.write(this.playerName + "\n");// name 
            out.write(this.difficulty + "\n");// level
        } catch (IOException e) {
            System.out.println("Error saving game state: " + e.getMessage());
        }
    }

    // Method to load game state txt 
    public static PlayerProfile loadGameState() {
        File saveFile = new File("gamestate.txt");
        if (saveFile.exists()) {
            try (BufferedReader in = new BufferedReader(new FileReader(saveFile))) {
                String playerName = in.readLine();// read name 
                int difficulty = Integer.parseInt(in.readLine());// read level
                PlayerProfile playerProfile = new PlayerProfile(playerName);
                playerProfile.setDifficulty(difficulty);
                return playerProfile;
            } catch (IOException e) {
                System.out.println("Error loading game state: " + e.getMessage());
            }
        }
        return null;
    }
  //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                : Main 
    //
    // Method parameters    : Ask name and resume the game if save game is found
    //
    // Method return        :
    //
    // Synopsis                : 
    //
    // Modifications        :
    //                            Date            Developer            Notes
    //                            5/6/23            Dhruvit            Every saved game is found
    //
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
        	//Game is made by DP
            JOptionPane.showMessageDialog(null, "Welcome to Number Cruncher Made by Dhruvit Patel");
            // saving is only two ways closing tab or next level button for all easy medium and hard
            JOptionPane.showMessageDialog(null, "Game is saved in two ways: Closing Tab \nand pressing Next level.\n!!!! Thank You, enjoy the Game");
  
            
            PlayerProfile playerProfile = loadGameState();
            if (playerProfile == null) {
                // If no saved game was found, ask the user for their name
                String playerName = JOptionPane.showInputDialog(null, "Enter your username:");
                while (playerName == null || playerName.trim().isEmpty()) {
                    playerName = JOptionPane.showInputDialog(null, "Enter your username:");
                }
                playerProfile = new PlayerProfile(playerName);
            } else {
            	
                // If a saved game was found, ask the user if they want to resume
                int option = JOptionPane.showConfirmDialog(null, "A saved game was found for " + playerProfile.getPlayerName() + ". Do you want to resume?", "Resume game", JOptionPane.YES_NO_OPTION);
               
                if (option == JOptionPane.NO_OPTION) {
                    String playerName = JOptionPane.showInputDialog(null, "Enter your username:");
                    while (playerName == null || playerName.trim().isEmpty()) {
                        playerName = JOptionPane.showInputDialog(null, "Enter your username:");
                    }
                    playerProfile = new PlayerProfile(playerName);
                }
            }

            playerProfile.prepareGUI();
            
            // Load the correct game based on difficulty
            int difficulty = playerProfile.getDifficulty();
            if (difficulty == EASY) {
                Easy easy = new Easy(playerProfile.getPlayerName());
                easy.setVisible(true);
            } else if (difficulty == MODERATE) {
                Medium medium = new Medium(playerProfile.getPlayerName());
                medium.setVisible(true);
            } else if (difficulty == HARD) {
                high hard = new high(playerProfile.getPlayerName());
                hard.setVisible(true);
            }
        });
    }


	// Inner class to handle the difficulty button click events
    class DifficultyButtonListener implements ActionListener {
    	 private int difficulty;

         DifficultyButtonListener(int difficulty) {
             this.difficulty = difficulty;
         }
         // This method will be called when a difficulty button is clicked
         public void actionPerformed(ActionEvent e) {
             swing.dispose();
             setDifficulty(difficulty);
             saveGameState();

            if (difficulty == EASY) { //Easy will be open
                Easy easy = new Easy(playerName);
                easy.setVisible(true);
            } else if (difficulty == MODERATE) {//Medium will be open
                Medium medium = new Medium(playerName);
                medium.setVisible(true);
            } else if (difficulty == HARD) {//Hard will be open
                high hard = new high(playerName);
                hard.setVisible(true);
            }
            swing.dispose();//close frame
        }
    }
}
