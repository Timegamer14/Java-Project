import javax.swing.*;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;
import java.util.Random;
import java.io.*;
import java.util.Scanner;

public class Easy extends JFrame implements Serializable {
	 private static final long serialVersionUID = 1L;
 // Declare labels, text fields, buttons, and ArrayLists to hold game data
 private JLabel lblGuess, scoreLabel, levelLabel, score1, level1, levelRangeLabel,track1AttemptsLabel,track2AttemptsLabel,track3AttemptsLabel,track4AttemptsLabel,track5AttemptsLabel,track6AttemptsLabel,track7AttemptsLabel;
 private JTextField track1, track2, track3; // track 1,2,3,4,5,6,7
 private JButton guessButton; // guess button
 private ArrayList<Integer> correctGuesses = new ArrayList<>(); // store correct guess 
 private ArrayList<Integer> completedLevels = new ArrayList<>(); //store completed level
 private ArrayList<Integer> guessedTracks = new ArrayList<>();// store guess tracks 
 private JLabel previousGuessLabel1;  //store previous guess 1 2 3
 private JLabel previousGuessLabel2;
 private JLabel previousGuessLabel3;
 String initials;
 // Declare and initialize variables to hold game state
 private int track1Attempts = 5;   // attempts 1 2 3 4 5 6 7
 private int track2Attempts = 5;
 private int track3Attempts = 5;
 private int track4Attempts = 7;
 private int track5Attempts = 7;
 private int track6Attempts = 11;
 private int track7Attempts = 11;
 private int level = 1;  // level 1 from 1-9
 private int tracks = 3; //track 3
 private String difficulty = "Easy"; //to store level easy 
 private int score; //store score 
 private int bonusAttempts = 0; // to store bonus attempts 
 private JButton nextLevelButton; // next level to go to next level
 private int currentTrack = 1; 
 private JLabel guessIndicator1, guessIndicator2, guessIndicator3,guessLabel1,guessLabel2,guessLabel3,sign3,sign2,sign1; //label to check sign and guess
 private int mode1; // three mode 
 private int mode2;
 private int mode3;
 public static int[] numbers1 = new int[1000]; // Array to store numbers for the game
 public static int[] numbers2 = new int[1000]; // Array to store numbers for the game
 public static int[] numbers3 = new int[1000]; // Array to store numbers for the game
 public static int maxNumber = 10;
 private JLabel playerNameLabel; // player name

 private ArrayList<Integer> guessedNumbers = new ArrayList<>();

 // Declare a variable to hold the player's profile data
 private PlayerProfile userProfile;
 
 // Constructor method for the Easy class. It takes a String parameter representing the player's initials.
 public Easy(String initials) {
	 this.initials = initials;// Create a new PlayerProfile object with the player's initials
	 userProfile = new PlayerProfile(initials);
     currentTrack = 0; // Initialize the current track to 0
     loadGameState(); // Load the game state if it exists
     initialize(); // Call the initialize method to set up the game
     changeTrack();
     dispose();
 }


    private void initialize() {
    	setTitle("Easy Level");
    	setSize(800, 533);

    	// add a window listener to save the game state when window is closing
    	addWindowListener(new WindowAdapter() {
    	    @Override
    	    public void windowClosing(WindowEvent e) {
    	        // Call the method that saves the game state
    	        saveGameState();
    	        System.out.println("Game state saved.");
    	    }
    	});

    	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    	getContentPane().setLayout(null);

        // Add labels, text fields, buttons, and table to the frame
        lblGuess = new JLabel("Guess Number");
        lblGuess.setBounds(12, 95, 115, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(lblGuess);
        
        lblGuess = new JLabel("3");
        lblGuess.setBounds(453, 65, 35, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(lblGuess);
        lblGuess = new JLabel("2");
        lblGuess.setBounds(316, 65, 35, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(lblGuess);
        lblGuess = new JLabel("1");
        lblGuess.setBounds(179, 65, 35, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(lblGuess);
        
        
        // Add labels for "GUESSES"
        lblGuess = new JLabel("Guess Numbered");
        lblGuess.setBounds(12, 171, 124, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(lblGuess);
        
        // Add label for "SIGN"
        lblGuess = new JLabel("Assist Arrow");
        lblGuess.setBounds(12, 130, 96, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(lblGuess);
        
        // Add label for "Check Guesses"
        lblGuess = new JLabel("Match ?");
        lblGuess.setBounds(12, 200, 124, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(lblGuess);
        
        lblGuess = new JLabel("Previous Guessed");
        lblGuess.setBounds(12, 241, 136, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(lblGuess);
        
        lblGuess = new JLabel("Lives");
        lblGuess.setBounds(127, 324, 45, 31); // Increase the label height to accommodate larger font
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(lblGuess);
        // Add labels for displaying individual guesses1
        previousGuessLabel1 = new JLabel("");
        previousGuessLabel1.setBounds(169, 241, 72, 46);
        previousGuessLabel1.setFont(previousGuessLabel1.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(previousGuessLabel1);
        // Add labels for displaying individual guesses2
        previousGuessLabel2 = new JLabel("");
        previousGuessLabel2.setBounds(302, 241, 72, 46);
        previousGuessLabel2.setFont(previousGuessLabel2.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(previousGuessLabel2);
        // Add labels for displaying individual guesses3
        previousGuessLabel3 = new JLabel("");
        previousGuessLabel3.setBounds(439, 241, 72, 46);
        previousGuessLabel3.setFont(previousGuessLabel3.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(previousGuessLabel3);

        loadGameState();
        
        // Add labels for displaying individual guesses1
        guessLabel1 = new JLabel("");
        guessLabel1.setBounds(169, 171, 72, 46);
        guessLabel1.setFont(guessLabel1.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessLabel1);
        // Add labels for displaying individual guesses2
        guessLabel2 = new JLabel("");
        guessLabel2.setBounds(302, 171, 72, 46);
        guessLabel2.setFont(guessLabel2.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessLabel2);
        // Add labels for displaying individual guesses3
        guessLabel3 = new JLabel("");
        guessLabel3.setBounds(439, 171, 72, 46);
        guessLabel3.setFont(guessLabel3.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessLabel3);
        
        // Add labels for displaying comparison signs
        sign1 = new JLabel("");
        sign1.setBounds(169, 200, 72, 46);
        sign1.setFont(sign1.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(sign1);
        // Add labels for displaying sign2
        sign2 = new JLabel("");
        sign2.setBounds(302, 200, 72, 46);
        sign2.setFont(sign2.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(sign2);
     // Add labels for displaying sign2
        sign3 = new JLabel("");
        sign3.setBounds(439, 200, 72, 46);
        sign3.setFont(sign3.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(sign3);
        
        
        // Add guess indicators for the target numbers
        guessIndicator1 = new JLabel("");
        guessIndicator1.setBounds(169, 125, 72, 46);
        guessIndicator1.setFont(guessIndicator1.getFont().deriveFont(Font.BOLD, 26f)); // Set the font to bold and size 16
        getContentPane().add(guessIndicator1);
        
        // Add guess indicators for the target numbers
        guessIndicator2 = new JLabel("");
        guessIndicator2.setBounds(302, 122, 72, 52);
        guessIndicator2.setFont(guessIndicator2.getFont().deriveFont(Font.BOLD, 26f)); // Set the font to bold and size 16
        getContentPane().add(guessIndicator2);
        
        // Add guess indicators for the target numbers
        guessIndicator3 = new JLabel("");
        guessIndicator3.setBounds(429, 128, 74, 41);
        guessIndicator3.setFont(guessIndicator3.getFont().deriveFont(Font.BOLD, 26f)); // Set the font to bold and size 16
        getContentPane().add(guessIndicator3);
        // Set the values for the guess indicators
      
        // Add the "Next Level" button
        nextLevelButton = new JButton("Next Level");
        nextLevelButton.setBounds(661, 140, 115, 41);
        getContentPane().add(nextLevelButton);
        nextLevelButton.setEnabled(false);
        nextLevelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	saveGameState();// save game
            	changeMedium ();//change mediuum
            	changeLevel();//change level
            
               
                nextLevelButton.setEnabled(false);
                guessButton.setEnabled(true); 
            }
        });
       

        
        // Add text fields for user input
        track1 = new JTextField(5);
        track1.setBounds(146, 95, 101, 29);
        getContentPane().add(track1);
        // Add text fields for user input
        track2 = new JTextField(5);
        track2.setBounds(279, 95, 96, 31);
        getContentPane().add(track2);
        // Add text fields for user input
        track3 = new JTextField(5);
        track3.setBounds(412, 95, 101, 31);
        getContentPane().add(track3);
//Display method
        JLabel arrowLabel = new JLabel("↑ means guess higher, ↓ means guess lower, ✓ Correct");
        arrowLabel.setBounds(77, 28, 529, 41);
        arrowLabel.setFont(arrowLabel.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(arrowLabel);
        
        JLabel message = new JLabel("To Save game Closing tab Or Complete one level and click next Level");
        message.setBounds(100, 434, 662, 41);
        message.setFont(message.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(message);

        // Add the "Play" button
        guessButton = new JButton("Play");
        guessButton.setBounds(661, 90, 115, 41);
        getContentPane().add(guessButton);
        
        guessButton.setEnabled(true);
        guessButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkGuess();
                
               

            }
        });

        generateMode();
        nextLevelButton.setEnabled(false);
        // Add the player name label
        playerNameLabel = new JLabel();
        playerNameLabel.setBounds(301, 5, 200, 13);
        playerNameLabel.setFont(playerNameLabel.getFont().deriveFont(Font.BOLD, 14f));
        getContentPane().add(playerNameLabel);
        updatePlayerNameLabel();

        // Add score label
        scoreLabel = new JLabel("Score: ");
        scoreLabel.setBounds(0, 5, 84, 13);
        scoreLabel.setFont(scoreLabel.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(scoreLabel);

        // Add score number label
        score1 = new JLabel(Integer.toString(score));
        score1.setBounds(67, 5, 45, 13);
        score1.setFont(score1.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(score1);

        // Add level label
        levelLabel = new JLabel("Level: ");
        levelLabel.setBounds(114, 5, 84, 13);
        levelLabel.setFont(levelLabel.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 12
        getContentPane().add(levelLabel);

        // Add level number label
        level1 = new JLabel("0");
        level1.setBounds(169, 4, 45, 13);
        level1.setFont(level1.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(level1);
        loadGameState();
        // Add level range label
        levelRangeLabel = new JLabel("Range: 1 -" + maxNumber);
        levelRangeLabel.setBounds(193, -3, 115, 28);
        levelRangeLabel.setFont(levelRangeLabel.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 12
        getContentPane().add(levelRangeLabel);

        loadGameState();
     // Add labels for displaying the remaining attempts for each track
        track1AttemptsLabel = new JLabel(" " + track1Attempts);
        track1AttemptsLabel.setBounds(192, 327, 84, 20);
        track1AttemptsLabel.setFont(track1AttemptsLabel.getFont().deriveFont(Font.BOLD, 20f));
        getContentPane().add(track1AttemptsLabel);
        loadGameState();
        track2AttemptsLabel = new JLabel(" " + track2Attempts);
        track2AttemptsLabel.setBounds(316, 327, 84, 20);
        track2AttemptsLabel.setFont(track2AttemptsLabel.getFont().deriveFont(Font.BOLD, 20f));
        getContentPane().add(track2AttemptsLabel);
        loadGameState();
        track3AttemptsLabel = new JLabel(" " + track3Attempts);
        track3AttemptsLabel.setBounds(453, 327, 84, 20);
        track3AttemptsLabel.setFont(track3AttemptsLabel.getFont().deriveFont(Font.BOLD, 20f));
        getContentPane().add(track3AttemptsLabel);
        loadGameState();
      
        updateLevelLabel();
       
        // Add background image
        ImageIcon backgroundImageIcon = new ImageIcon("Media/bg.png");
        JLabel backgroundLabel = new JLabel(backgroundImageIcon);
        backgroundLabel.setBounds(0, 0, 800, 522);
        getContentPane().add(backgroundLabel);
        
        
    }
    // This method saves the game state to a file
    private void saveGameState() {
        try (PrintWriter out = new PrintWriter(new FileOutputStream(initials + "_gamestate.txt"))) {
        	// Save game variables to the file
            out.println(score);
            out.println(level); 
            out.println(difficulty);
            out.println(track1Attempts);
            out.println(track2Attempts);
            out.println(track3Attempts);
            out.println(track4Attempts);
            out.println(track5Attempts);
            out.println(track6Attempts);
            out.println(track7Attempts);
            out.println(maxNumber);

            System.out.println("Game state saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving game state: " + e.getMessage());
        }
    }
    // This method loads the game state from a file
    private void loadGameState() {
        try (Scanner scanner = new Scanner(new FileInputStream(initials + "_gamestate.txt"))) {
        	// Load game variables from the file
            
            score = scanner.nextInt();
            level = scanner.nextInt();
            difficulty = scanner.next();
            track1Attempts = scanner.nextInt();
            track2Attempts = scanner.nextInt();
            track3Attempts = scanner.nextInt();
            track4Attempts = scanner.nextInt();
            track5Attempts = scanner.nextInt();
            track6Attempts = scanner.nextInt();
            track7Attempts = scanner.nextInt();
            maxNumber = scanner.nextInt();

            System.out.println("Game state loaded successfully.");
        } catch (IOException e) {
            System.out.println("Error loading game state: " + e.getMessage());
        }
    }
  //Change the difficulty level
    private void changeDifficulty(String newDifficulty) {
      difficulty = newDifficulty;
    }
    // This method checks if the game state matches certain conditions to change to the Medium difficulty
   private void changeMedium ()
   {
	   if (maxNumber ==90 && level ==9) {
	  
           dispose();
           Medium medium = new Medium(initials);
           medium.setVisible(true);
           
	   }
	 
   }
   //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
   // Method                : Generate number
   //
   // Method parameters    :For easy from 1-100
   //
   // Method return        :Mode 
   //
   // Synopsis                : check all three methods 
   //
   // Modifications        :
   //                            Date            Developer            Notes
   //                            5/6/23            Dhruvit            
   //
   //
   //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method to generate the target numbers for the track
    private void generateMode() {
        // Initialize the array of numbers
        numbers1 = new int[1000];
        numbers2 = new int[1000];
        numbers3 = new int[1000];
        // Define a random generator and a range for generating numbers
        Random random = new Random();
        int minNumber = 1;
        int maxNumber = 10 * level;
        String levelRange = minNumber + " - " + maxNumber;

        do {
            generateNumbers(numbers1, random, minNumber, maxNumber);
            generateNumbers(numbers2, random, minNumber, maxNumber);
            generateNumbers(numbers3, random, minNumber, maxNumber);
            // Generate random numbers for the three arrays and find their modes
            // Repeat until we have unique modes for each array
            mode1 = findMode(numbers1);
            mode2 = findMode(numbers2);
            mode3 = findMode(numbers3);
        } while (hasMultipleModes(mode1, mode2, mode3));

        
    }
 // This method populates an array with random numbers within a given range
   private void generateNumbers(int[] numbers, Random random, int minNumber, int maxNumber) {
	    for (int i = 0; i < 1000; i++) {
	        numbers[i] = random.nextInt(maxNumber - minNumber + 1) + minNumber;
	    }
	}
   // This method finds the mode (most frequent number) in an array
	private int findMode(int[] numbers) {
        int element = 0;
        int count = 0;

        for (int j = 0; j < numbers.length; j++) {
            int tempElement = numbers[j];
            int tempCount = 0;

            for (int p = 0; p < numbers.length; p++) {
                if (numbers[p] == tempElement) {
                    tempCount++;
                }
            }

            if (tempCount > count) {
                element = tempElement;
                count = tempCount;
            }
        }

        return element;
    }
	 // This method checks if there are multiple identical modes among three given modes
    private boolean hasMultipleModes(int mode1, int mode2, int mode3) {
        return (mode1 == mode2 && mode1 != mode3)
            || (mode1 == mode3 && mode1 != mode2)
            || (mode2 == mode3 && mode2 != mode1);
    }

    // Method to update the player name label
    private void updatePlayerNameLabel() {
        playerNameLabel.setText("Player: " + userProfile.getPlayerName());
    }
  
    private void changeLevel() {
        level++; // Increment the current level
        
      
        // We add the previous level's remaining attempts and bonus attempts to get total attempts for the new level
        track1Attempts += (5 + bonusAttempts);
        track2Attempts += (5 + bonusAttempts);
        track3Attempts += (5 + bonusAttempts);
        bonusAttempts = 0; // Reset bonus attempts for the new level

        // Clear text fields for each track
        track1.setText("");
        track2.setText("");
        track3.setText("");

        // Enable text fields for each track
        track1.setEnabled(true);
        track2.setEnabled(true);
        track3.setEnabled(true);

        // Clear guess indicators for each track
        guessIndicator1.setText("");
        guessIndicator2.setText("");
        guessIndicator3.setText("");
     // Clear the list of guessed numbers
        guessedNumbers.clear();
        // Move focus to the first track
        track1.requestFocus();
        
        previousGuessLabel1.setText("");
        previousGuessLabel2.setText("");
        previousGuessLabel3.setText("");

        // Update the attempts label to display the new number of attempts
     // Update the remaining track attempts labels
        track1AttemptsLabel.setText("" + track1Attempts);
        track2AttemptsLabel.setText("" + track2Attempts);
        track3AttemptsLabel.setText("" + track3Attempts);
        if (level >= 1 && level <= 10) {
            maxNumber = level * 10;
        }
        levelRangeLabel.setText("Range: 1 - " + maxNumber);

        updateLevelLabel(); // Update the label showing the current level

        generateMode(); // Generate new game mode for the new level
        // Clear the list of correct guesses from the previous level
        correctGuesses.clear();
     
        updateScoreLabel();
        
       
    }


	// Method to update the level label
    private void updateLevelLabel() {
        level1.setText(String.valueOf(level));
    }

    // Method to update the score label
    private void updateScoreLabel() {
        score1.setText(String.valueOf(score));
    }

    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                :  Check guess check attempts and score and tracks
    //
    // Method parameters    :to check every tracks and attmepts and score
    //
    // Method return        :
    //
    // Synopsis                : 
    //
    // Modifications        :
    //                            Date            Developer            Notes
    //                            5/6/23            Dhruvit            
    //
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method to check the user's guess
    private void checkGuess() {
    	// If no attempts are remaining, show a message, save the score, and ask if the user wants to restart the game
    	  // If no attempts are remaining for the current track, show a message and return
        if ((  track1Attempts == 0) ||
            ( track2Attempts == 0) ||
            (  track3Attempts == 0)) {
        	 JOptionPane.showMessageDialog(this, "Out of attempts for this track");
        	 showGameOverMessage();
  	        userProfile.setScore(score);  // Save the score to the user's profile
  	        // Ask the user if they want to restart the game
  	        int option = JOptionPane.showConfirmDialog(this, "Game Over! Do you want to restart the game?", "Game Over", JOptionPane.YES_NO_OPTION);
  	        // If the user wants to restart, call the restartGame method
  	        if (option == JOptionPane.YES_OPTION) {
  	            restartGame();
  	        } else {
  	            // If the user does not want to restart, close the application
  	            System.exit(0);
  	        }
  	        return;
        }

        // Variables to store the guesses
        int guess1, guess2, guess3;
        
        // Try to convert the input text to integers, if it fails show a message and return
        try {
            guess1 = Integer.parseInt(track1.getText());
            guess2 = Integer.parseInt(track2.getText());
            guess3 = Integer.parseInt(track3.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Invalid input. Please enter a number.");
            return;
        }
       //guess must be between same range
        
        if (guess1 < 1 || guess1 > maxNumber || guess2 < 1 || guess2 > maxNumber || guess3 < 1 || guess3 > maxNumber) {
            JOptionPane.showMessageDialog(this, "Invalid guess. Please enter a number between 1 and " + maxNumber + ".");
            return;
        }
        // Set a flag to true. This flag will be set to false if any of the guesses is incorrect.
        boolean allCorrect = true;

        // Check if guess1 is incorrect and if it has not been guessed correctly before
        if (guess1 != mode1 && !guessedTracks.contains(1)) {
            allCorrect = false;
            if (guess1 < mode1) {
                guessIndicator1.setText("↑");
                sign1.setText("X");
            } else {
                guessIndicator1.setText("↓");
                sign1.setText("X");
            }
            track1Attempts--;
        } else {

            guessedTracks.add(1);
            sign1.setText("✓");
            guessLabel1.setText(Integer.toString(guess1)); // Update guessLabel1 with the current guess value
            track1.setEnabled(false);

            guessIndicator1.setEnabled(false);
            if (!correctGuesses.contains(1)) {
            	 // Calculate the score based on spare attempts
            	int spareGuesses = track1Attempts;

                while(spareGuesses > 0) {
                  if (spareGuesses >= 3) {
                      score += 50; // Bonus points for guessing in 3 attempts or less
  spareGuesses -= 3;
                  }
                  else {
                       score += 10 * spareGuesses;
  spareGuesses -= 1;
                  }  userProfile.setScore(score);
                correctGuesses.add(1);
            }
        }
    }
        // Check if guess2 is incorrect and if it has not been guessed correctly before
        if (guess2 != mode2 && !guessedTracks.contains(2)) {
            allCorrect = false;
            if (guess2 < mode2) {
                guessIndicator2.setText("↑");
                sign2.setText("X");
            } else {
                guessIndicator2.setText("↓");
                sign2.setText("X");
            }
            track2Attempts--;
        } else {
            
            guessedTracks.add(2);
            sign2.setText("✓");
            guessLabel2.setText(Integer.toString(guess2)); // Update guessLabel2 with the current guess value
            track2.setEnabled(false);

            guessIndicator2.setEnabled(false);
            if (!correctGuesses.contains(2)) {
            	int spareGuesses = track2Attempts;

                while(spareGuesses > 0) {
                  if (spareGuesses >= 3) {
                      score += 50; // Bonus points for guessing in 3 attempts or less
  spareGuesses -= 3;
                  }
                  else {
                       score += 10 * spareGuesses;
  spareGuesses -= 1;
                  }  userProfile.setScore(score);
                correctGuesses.add(2);
            }
        }
        }
        // Check if guess3 is incorrect and if it has not been guessed correctly before
        if (guess3 != mode3 && !guessedTracks.contains(3)) {
            allCorrect = false;
            if (guess3 < mode3) {
                guessIndicator3.setText("↑");
                sign3.setText("X");
            } else {
                guessIndicator3.setText("↓");
                sign3.setText("X");
            }
            track3Attempts--;
        } else {
           
            guessedTracks.add(3);
            sign3.setText("✓");
            guessLabel3.setText(Integer.toString(guess3)); // Update guessLabel3 with the current guess value
            track3.setEnabled(false);

            guessIndicator3.setEnabled(false);
            if (!correctGuesses.contains(3)) {
            	int spareGuesses = track3Attempts;

                while(spareGuesses > 0) {
                  if (spareGuesses >= 3) {
                      score += 50; // Bonus points for guessing in 3 attempts or less
  spareGuesses -= 3;
                  }
                  else {
                       score += 10 * spareGuesses;
  spareGuesses -= 1;
                  } 
                userProfile.setScore(score);
                correctGuesses.add(3);
            }
        }
        // If all guesses are correct
        }
        if (allCorrect) {
	
            

            if (correctGuesses.size() == tracks) { // Check if all tracks have been guessed correctly
		                    
                JOptionPane.showMessageDialog(this, "Level completed! Moving to next level...");

                // Update the attempts label
                nextLevelButton.setEnabled(true);
             // Disable the guess button
                guessButton.setEnabled(false);
                
                changeTrack();
            }        
                                            // If the user has not guessed all tracks yet, display a message and prepare for the next guess

            else {
                JOptionPane.showMessageDialog(this, "Level completed! Moving to next level....");
                nextLevelButton.setEnabled(true);
                track1AttemptsLabel.setText("" + track1Attempts);
                track2AttemptsLabel.setText("" + track2Attempts);
                track3AttemptsLabel.setText("" + track3Attempts);

                track1.setText("");
                track2.setText("");
                track3.setText("");
                track1.setEnabled(true); // Enable the text fields for the next set of guesses
                track2.setEnabled(true);
                track3.setEnabled(true);
                guessIndicator1.setText("");
                guessIndicator2.setText("");
                guessIndicator3.setText("");
                track1.requestFocus();
                guessButton.setEnabled(false);
            }
        } else {        // If not all guesses were correct, decrease the number of attempts and move to the next track if no attempts are left

        	
             
             if (track1Attempts == 0 && track2Attempts == 0 && track3Attempts == 0) {
                 JOptionPane.showMessageDialog(this, "Out of attempts for all tracks!");
                 showGameOverMessage();
                 userProfile.setScore(score); // Save the score to the user's profile
                 int option = JOptionPane.showConfirmDialog(this, "Game Over! Do you want to restart the game?", "Game Over", JOptionPane.YES_NO_OPTION);
                 if (option == JOptionPane.YES_OPTION) {
                	  
                     restartGame();
                 } else {
                     System.exit(0);
                 }
                 return;
             }
            
        }
        
        guessLabel1.setText(Integer.toString(guess1)); // Display guess1 in guessLabel1
        guessLabel2.setText(Integer.toString(guess2)); // Display guess2 in guessLabel2
        guessLabel3.setText(Integer.toString(guess3)); // Display guess3 in guessLabel3
     // Update the attempts labels after each guess
        track1AttemptsLabel.setText("" + track1Attempts);
        track2AttemptsLabel.setText("" + track2Attempts);
        track3AttemptsLabel.setText("" + track3Attempts);
     // Display previous guesses in the labels
       
            // Update the previous guesses labels
            previousGuessLabel1.setText(previousGuessLabel1.getText() + " " + guess1);
            previousGuessLabel2.setText(previousGuessLabel2.getText() + " " + guess2);
            previousGuessLabel3.setText(previousGuessLabel3.getText() + " " + guess3);


        guessedTracks.clear();
        updateScoreLabel();
    
    }

    // Method to restart the game
    private void restartGame() {
    	 
        // Reset the game score to 0
        score = 0;

        // Set the game level to 1
        level = 1;

        // Set the number of attempts to 5
        track1Attempts = 5;
        track2Attempts = 5;
        track3Attempts = 5;
        track1AttemptsLabel.setText("" + track1Attempts);
        track2AttemptsLabel.setText("" + track2Attempts);
        track3AttemptsLabel.setText("" + track3Attempts);
        // Reset bonus attempts to 0
        bonusAttempts = 0;

        // Set the current track to 1
        currentTrack = 1;

        // Clear the list of correct guesses
        correctGuesses.clear();

        // Clear the list of completed levels
        completedLevels.clear();

        // Clear the list of guessed tracks
        guessedTracks.clear();

        // Clear the text in the track text fields
        track1.setText("");
        track2.setText("");
        track3.setText("");

        // Enable all the track text fields
        track1.setEnabled(true);
        track2.setEnabled(true);
        track3.setEnabled(true);
        

	    previousGuessLabel3.setText("");
	    previousGuessLabel2.setText("");
	    previousGuessLabel1.setText("");


        // Clear the text in the guess indicator fields
        guessIndicator1.setText("");
        guessIndicator2.setText("");
        guessIndicator3.setText("");
        if (level >= 1 && level <= 9) {
            maxNumber = level * 10;
        }
        levelRangeLabel.setText("Range: 1 - " + maxNumber);
        // Remove all rows from the table model


        // Update the score label with the new score
        updateScoreLabel();

        // Update the level label with the new level
        updateLevelLabel();

        // Generate new game data (modes for guessing)
        generateMode();

        // Set focus to the first track text field
        track1.requestFocus();
       
    }
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                :  Track and level is inset in this to complete all track add bonus attempts 
    //
    // Method parameters    :Store bonus attempts 
    //
    // Method return        :
    //
    // Synopsis                : 
    //
    // Modifications        :
    //                            Date            Developer            Notes
    //                            5/6/23            Dhruvit            
    //
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method to change to the next track or level
    private void changeTrack() {
        // Array containing text fields for each track

        JTextField[] totalTracks = {track1, track2, track3};
        int totalLevels = 9;
        // Total number of levels in the game
        // If the current track is not the last, increment current track

        if (currentTrack < totalTracks.length) {
           
        } else {        // If it's the last track and it's not the last level, increment level and reset current track

        	if (level < totalLevels) {
                level++;
                userProfile.addCompletedLevels(level);
                updateLevelLabel();
            }
        	else { // If it's the last level
               
                // If it's the last level and the difficulty is not 'easy', show game over message
                JOptionPane.showMessageDialog(this, "Congratulations! You've finished all the levels.");
            
            }
            }
        

        if (completedLevels.size() == totalLevels) {
	        JOptionPane.showMessageDialog(this, "Congratulations! You've finished all the levels.");
	        showGameOverMessage();  // Show the game over message
	      
	        
	    }
        
        for (JTextField totalTrack : totalTracks) {
            totalTrack.setEnabled(true);
            totalTrack.setText(""); // Clear the text fields
        }
        // Enable guess indicators and clear their content

        guessIndicator1.setEnabled(true);
        guessIndicator2.setEnabled(true);
        guessIndicator3.setEnabled(true);

        guessIndicator1.setText("");
        guessIndicator2.setText("");
        guessIndicator3.setText("");
        // Set the values for the guess indicators
     // Clear the previous guess labels
        previousGuessLabel1.setText("");
        previousGuessLabel2.setText("");
        previousGuessLabel3.setText("");
        track1.requestFocus();

        userProfile.setScore(score);

        if (track1Attempts  <= 0) {
        	track1Attempts  = 5; // Reset attempts only when no attempts are remaining
        }
        if (track2Attempts  <= 0) {
        	track2Attempts  = 5; // Reset attempts only when no attempts are remaining
        }
        if (track3Attempts  <= 0) {
        	track3Attempts  = 5; // Reset attempts only when no attempts are remaining
        }

        track1Attempts  += bonusAttempts;
        track2Attempts  += bonusAttempts;
        track3Attempts  += bonusAttempts;// Add bonusAttempts to new track's attempts
        bonusAttempts = 0; // Reset bonusAttempts

      
        generateMode();
        // Clear the list of correct guesses
        guessedNumbers.clear();

        // Clear the table

        correctGuesses.clear();
        // Clear the table model

       
        updateLevelLabel();
     
    }

	// Method to display the game over message
    private void showGameOverMessage() {
        String message = "Game Over!";
        message += "Player: " + userProfile.getPlayerName() + "\n";//Name 		
        //Score
        message += "Score: " + userProfile.getScore() + "\n";
        //Level
message += "Level: "+level +"\n";

        // Display the game over message
        JOptionPane.showMessageDialog(this, message);

    }
    
      
    }


