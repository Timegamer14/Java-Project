import javax.swing.*;


import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

import java.io.PrintWriter;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class high extends JFrame implements Serializable {
	 private static final long serialVersionUID = 1L;
	private JLabel lblGuess, scoreLabel, levelLabel, score1,  level1,levelRangeLabel,track1AttemptsLabel,track2AttemptsLabel,track3AttemptsLabel,track4AttemptsLabel,track5AttemptsLabel,track6AttemptsLabel,track7AttemptsLabel;
   
    // Define button for submitting guesses
    private JButton guessButton; // button to guess
    
    // Define ArrayLists to keep track of correct guesses, completed levels, and guessed tracks
    private ArrayList<Integer> correctGuesses = new ArrayList<>(); // check correct guess	
    private ArrayList<Integer> completedLevels = new ArrayList<>();// check completed level
    private ArrayList<Integer> guessedTracks = new ArrayList<>();// to check guess track
    private ArrayList<Integer> guessedNumbers = new ArrayList<>();// to check guess number
    // Define text fields for guessing tracks
    private JTextField track1, track2, track3, track4, track5,track6 ,track7;
    
    // Define variables for game level, bonus attempts, and tracks
    private int level =1;  //level	
    private int bonusAttempts = 0; //bonus attempts 
    private int tracks;     //tracks 1234567
    private int track1Attempts = 11; //attempts 1234567
    private int track2Attempts = 11;
    private int track3Attempts = 11;
    private int track4Attempts = 11;
    private int track5Attempts = 11;
    private int track6Attempts = 11;
    private int track7Attempts = 11;
    public static int[] numbers1 = new int[1000]; // Array to store numbers for the game
    public static int[] numbers2 = new int[1000]; // Array to store numbers for the game
    public static int[] numbers3 = new int[1000]; // Array to store numbers for the game
    public static int[] numbers4 = new int[1000]; // Array to store numbers for the game
    public static int[] numbers5 = new int[1000]; // Array to store numbers for the game
    public static int[] numbers6 = new int[1000]; // Array to store numbers for the game
    public static int[] numbers7 = new int[1000]; // Array to store numbers for the game
    public static int maxNumber = 1000;
    // Define button for moving to the next level
    private JButton nextLevelButton;
    private String initials;
    // Define label for displaying the player's name
    private JLabel playerNameLabel;
    // Define variable for the score
    private int score;
    // Define variable for the current track and initialize it to 1
    private int currentTrack=1;
      private String difficulty = "Hard";
    // Define labels for guess indicators and guess labels
    private JLabel guessIndicator1, guessIndicator2, guessIndicator3, guessIndicator4, guessIndicator5,guessIndicator6, guessIndicator7,guessLabel1,guessLabel2,guessLabel3,guessLabel4,guessLabel5,guessLabel6,guessLabel7,sign7,sign6,sign5,sign4,sign3,sign2,sign1;    
    // Define variables for the mode of each track
    private int mode1, mode2, mode3, mode4, mode5, mode7, mode6;
       // Define an array to store numbers
    public static int[] numbers = new int[1000];
       // Define a player profile to store player's information
    private PlayerProfile userProfile;
    //all Previous Guess 1 -7
    private JLabel previousGuessLabel1;
    private JLabel previousGuessLabel2;
    private JLabel previousGuessLabel3;
    private JLabel previousGuessLabel4;
    private JLabel previousGuessLabel5;
    private JLabel previousGuessLabel6;
    private JLabel previousGuessLabel7;

    // Constructor to initialize the game with player's initials
    public high(String initials ) {
   	    this.initials = initials;
   // Initialize the player profile with the provided initials
         userProfile = new PlayerProfile(initials);
         
         // Set the current track to 0
         currentTrack =0;
       
         // Call the initialize method to set up the game
         initialize();
         loadGameState();
         // Call the changeTrack method to start the game with the first track
         changeTrack();
         dispose();
    }

	private void initialize() {
    	
        // Setting up the title, size, default close operation and layout of the JFrame
		setTitle("High Level");
		setSize(800, 533);

		// add a window listener to save the game state when window is closing
		addWindowListener(new WindowAdapter() {
		    @Override
		    public void windowClosing(WindowEvent e) {
		        // Call the method that saves the game state
		        saveGameState();
		        System.out.println("Game state saved.");
		    }
		});

		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		getContentPane().setLayout(null);

        // Initialising and setting up the guess labels with their font and bounds
        lblGuess = new JLabel("7");
        lblGuess.setBounds(548, 78, 112, 13);
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f));
        getContentPane().add(lblGuess);
        
        
        lblGuess = new JLabel("6");
        lblGuess.setBounds(489, 78, 112, 13);
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f));
        getContentPane().add(lblGuess);
        lblGuess = new JLabel("5");
        lblGuess.setBounds(425, 78, 112, 13);
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f));
        getContentPane().add(lblGuess);
        lblGuess = new JLabel("4");
        lblGuess.setBounds(349, 78, 112, 13);
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f));
        getContentPane().add(lblGuess);
        lblGuess = new JLabel("3");
        lblGuess.setBounds(296, 78, 112, 13);
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f));
        getContentPane().add(lblGuess);
        lblGuess = new JLabel("2");
        lblGuess.setBounds(235, 78, 112, 13);
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f));
        getContentPane().add(lblGuess);
        lblGuess = new JLabel("1");
        lblGuess.setBounds(163, 78, 35, 13);
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f));
        getContentPane().add(lblGuess);
        // label for all infromation guess Number assist arrow previous 
        lblGuess = new JLabel("Guess Number");
        lblGuess.setBounds(0, 106, 112, 13);
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f));
        getContentPane().add(lblGuess);
        
        
        lblGuess = new JLabel("Guess Numbered");
        lblGuess.setBounds(0, 173, 138, 31);
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f));
        getContentPane().add(lblGuess);
        
        lblGuess = new JLabel("Assist Arrow");
        lblGuess.setBounds(0, 129, 96, 31);
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f));
        getContentPane().add(lblGuess);
        
        lblGuess = new JLabel("Previous Guess");
        lblGuess.setBounds(0, 242, 133, 31);
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f));
        getContentPane().add(lblGuess);
        
        // all label to show previous guess 1 -7
        
        previousGuessLabel1 = new JLabel("");
        previousGuessLabel1.setBounds(455, 242, 72, 46);
        previousGuessLabel1.setFont(previousGuessLabel1.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(previousGuessLabel1);

        previousGuessLabel2 = new JLabel("");
        previousGuessLabel2.setBounds(222, 242, 72, 46);
        previousGuessLabel2.setFont(previousGuessLabel2.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(previousGuessLabel2);

        previousGuessLabel3 = new JLabel("");
        previousGuessLabel3.setBounds(275, 242, 72, 46);
        previousGuessLabel3.setFont(previousGuessLabel3.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(previousGuessLabel3);
        
        previousGuessLabel4 = new JLabel("");
        previousGuessLabel4.setBounds(337, 242, 72, 46);
        previousGuessLabel4.setFont(previousGuessLabel4.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(previousGuessLabel4);

        previousGuessLabel5 = new JLabel("");
        previousGuessLabel5.setBounds(404, 242, 72, 46);
        previousGuessLabel5.setFont(previousGuessLabel5.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(previousGuessLabel5);
        
        
        previousGuessLabel6 = new JLabel("");
        previousGuessLabel6.setBounds(140, 242, 72, 46);
        previousGuessLabel6.setFont(previousGuessLabel6.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(previousGuessLabel6);

        previousGuessLabel7 = new JLabel("");
        previousGuessLabel7.setBounds(537, 242, 72, 46);
        previousGuessLabel7.setFont(previousGuessLabel7.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(previousGuessLabel7);
      // All match is found
        lblGuess = new JLabel("Match?");
        lblGuess.setBounds(0, 203, 133, 31);
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f));
        getContentPane().add(lblGuess);
        
        // lives counter label
        lblGuess = new JLabel("Lives");
        lblGuess.setBounds(115, 320, 54, 31);
        lblGuess.setFont(lblGuess.getFont().deriveFont(Font.BOLD, 14f));
        getContentPane().add(lblGuess);
// sign1, sign2, sign3, sign4, sign5 are used to display the guess result signs, initially they are empty
        
        sign1 = new JLabel("");
        sign1.setBounds(471, 203, 54, 46);
        sign1.setFont(sign1.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(sign1);

        sign2 = new JLabel("");
        sign2.setBounds(222, 214, 49, 46);
        sign2.setFont(sign2.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(sign2);

        sign3 = new JLabel("");
        sign3.setBounds(281, 214, 49, 46);
        sign3.setFont(sign3.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(sign3);
        
        sign4 = new JLabel("");
        sign4.setBounds(340, 214, 54, 46);
        sign4.setFont(sign4.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(sign4);

        sign5 = new JLabel("");
        sign5.setBounds(411, 214, 50, 46);
        sign5.setFont(sign5.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(sign5);
        
        sign6 = new JLabel("");
        sign6.setBounds(148, 203, 46, 46);
        sign6.setFont(sign6.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(sign6);

        sign7 = new JLabel("");
        sign7.setBounds(537, 214, 49, 46);
        sign7.setFont(sign7.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(sign7);
        
     // guessLabel1, guessLabel2, guessLabel3, guessLabel4, guessLabel5 are used to display the guess result labels, initially they are empty
        
        guessLabel1 = new JLabel("");
        guessLabel1.setBounds(384, 410, 54, 46);
        guessLabel1.setFont(guessLabel1.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessLabel1);

        guessLabel2 = new JLabel("");
        guessLabel2.setBounds(225, 157, 46, 46);
        guessLabel2.setFont(guessLabel2.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessLabel2);

        guessLabel3 = new JLabel("");
        guessLabel3.setBounds(281, 160, 46, 46);
        guessLabel3.setFont(guessLabel3.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessLabel3);
        
        
        
        guessLabel4 = new JLabel("");
        guessLabel4.setBounds(337, 160, 54, 46);
        guessLabel4.setFont(guessLabel4.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessLabel4);

        guessLabel5 = new JLabel("");
        guessLabel5.setBounds(401, 160, 54, 46);
        guessLabel5.setFont(guessLabel5.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessLabel5);
        
        
        guessLabel6 = new JLabel("");
        guessLabel6.setBounds(143, 173, 54, 46);
        guessLabel6.setFont(guessLabel6.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessLabel6);

        guessLabel7 = new JLabel("");
        guessLabel7.setBounds(535, 160, 54, 46);
        guessLabel7.setFont(guessLabel7.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessLabel7);
        
        
        // guessIndicator1, guessIndicator2, guessIndicator3, guessIndicator4, guessIndicator5 are used to display the guessing indicators, initially they are empty

        guessIndicator1 = new JLabel("");
        guessIndicator1.setBounds(465, 132, 54, 32);
        guessIndicator1.setFont(guessIndicator1.getFont().deriveFont(Font.BOLD, 18f)); // Set the font to bold and size 16
        getContentPane().add(guessIndicator1);

        guessIndicator2 = new JLabel("");
        guessIndicator2.setBounds(215, 129, 56, 35);
        guessIndicator2.setFont(guessIndicator2.getFont().deriveFont(Font.BOLD, 18f)); // Set the font to bold and size 16
        getContentPane().add(guessIndicator2);

        guessIndicator3 = new JLabel("");
        guessIndicator3.setBounds(281, 133, 50, 31);
        guessIndicator3.setFont(guessIndicator3.getFont().deriveFont(Font.BOLD, 18f)); // Set the font to bold and size 16
        getContentPane().add(guessIndicator3);

        guessIndicator4 = new JLabel("");
        guessIndicator4.setBounds(341, 129, 50, 31);
        guessIndicator4.setFont(guessIndicator3.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessIndicator4);

        guessIndicator5 = new JLabel("");
        guessIndicator5.setBounds(401, 133, 54, 31);
        guessIndicator5.setFont(guessIndicator3.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessIndicator5);
        
        guessIndicator6 = new JLabel("");
        guessIndicator6.setBounds(144, 129, 54, 31);
        guessIndicator6.setFont(guessIndicator6.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessIndicator6);

        guessIndicator7 = new JLabel("");
        guessIndicator7.setBounds(529, 129, 54, 31);
        guessIndicator7.setFont(guessIndicator7.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(guessIndicator7);
        
        // Next Level button with action listener that changes level when pressed
        // Add the "Next Level" button
        nextLevelButton = new JButton("Next Level");
        nextLevelButton.setBounds(674, 140, 102, 41);
        getContentPane().add(nextLevelButton);
        nextLevelButton.setEnabled(false);
        nextLevelButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                changeLevel();
                if (level ==10) {
                	showGameOverMessage();
                }
                saveGameState();
                nextLevelButton.setEnabled(false);
                guessButton.setEnabled(true); 
            }
        });

        // Randomly generate a list of numbers for the game
        numbers = new int[1000];
        Random random = new Random();
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = random.nextInt(1000 * level) + 1;
        }

        // Label to help players understand the meaning of the signs
        JLabel arrowLabel = new JLabel("↑ means guess higher, ↓ means guess lower, ✓ Correct");
        arrowLabel.setBounds(84, 27, 529, 41);
        arrowLabel.setFont(arrowLabel.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(arrowLabel);

        JLabel message = new JLabel("To Save game Closing tab Or Complete one level and click next Level");
        message.setBounds(100, 434, 662, 41);
        message.setFont(message.getFont().deriveFont(Font.BOLD, 18f));
        getContentPane().add(message);

 
// guess button
        guessButton = new JButton("Play");
        guessButton.setBounds(675, 97, 101, 35);
        getContentPane().add(guessButton);
        guessButton.setEnabled(true);
        guessButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkGuess();
            }
        });

     // Create a label to display the score and set its font, position, and size
        scoreLabel = new JLabel("Score: ");
        scoreLabel.setBounds(12, 5, 100, 13);
        scoreLabel.setFont(scoreLabel.getFont().deriveFont(Font.BOLD, 14f)); 
        getContentPane().add(scoreLabel);  // Add the score label to the content pane
        loadGameState();
        // Create a label to display the level and set its font, position, and size
        levelLabel = new JLabel("Level: ");
        levelLabel.setBounds(114, 5, 84, 13);
        levelLabel.setFont(levelLabel.getFont().deriveFont(Font.BOLD, 14f)); 
        getContentPane().add(levelLabel);  // Add the level label to the content pane
        loadGameState();
        // Display the current level number 
        level1 = new JLabel("1");
        level1.setBounds(169, 4, 45, 13);
        level1.setFont(level1.getFont().deriveFont(Font.BOLD, 14f)); 
        getContentPane().add(level1);  // Add the level number to the content pane
        loadGameState();
        // Display the current level range 
        levelRangeLabel = new JLabel("Range: 1 -" + maxNumber);
        levelRangeLabel.setBounds(193, -3, 137, 28);
        levelRangeLabel.setFont(levelRangeLabel.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 12
        getContentPane().add(levelRangeLabel);
        loadGameState();
        // Display the current score 
        score1 = new JLabel(Integer.toString(score));
        score1.setBounds(67, 5, 45, 13);
        score1.setFont(score1.getFont().deriveFont(Font.BOLD, 14f)); // Set the font to bold and size 14
        getContentPane().add(score1);
        loadGameState();  // Add the score to the content pane

        // Create text fields for each track
        // The number in JTextField() indicates the columns of the field
        track1 = new JTextField(5);
        track1.setBounds(465, 101, 54, 33);
        getContentPane().add(track1);

        track2 = new JTextField(5);
        track2.setBounds(217, 98, 54, 33);
        getContentPane().add(track2);

        track3 = new JTextField(5);
        track3.setBounds(277, 98, 54, 33);
        getContentPane().add(track3);

        track4 = new JTextField(5);
        track4.setBounds(337, 98, 54, 33);
        getContentPane().add(track4);

        track5 = new JTextField(5);
        track5.setBounds(401, 98, 54, 33);
        getContentPane().add(track5);
        track6 = new JTextField(5);
        track6.setBounds(144, 98, 54, 33);
        getContentPane().add(track6);

        track7 = new JTextField(5);
        track7.setBounds(529, 98, 54, 33);
        getContentPane().add(track7);
        
        
        

     // Add labels for displaying the remaining attempts for each track
        track1AttemptsLabel = new JLabel(" " + track1Attempts);
        track1AttemptsLabel.setBounds(489, 331, 35, 13);
        getContentPane().add(track1AttemptsLabel);
        loadGameState();
        track2AttemptsLabel = new JLabel(" " + track2Attempts);
        track2AttemptsLabel.setBounds(235, 331, 30, 13);
        getContentPane().add(track2AttemptsLabel);
        loadGameState();
        track3AttemptsLabel = new JLabel(" " + track3Attempts);
        track3AttemptsLabel.setBounds(296, 331, 30, 13);
        getContentPane().add(track3AttemptsLabel);
        loadGameState();
        track4AttemptsLabel = new JLabel(" " + track4Attempts);
        track4AttemptsLabel.setBounds(364, 331, 30, 13);
        getContentPane().add(track4AttemptsLabel);
        loadGameState();
        track5AttemptsLabel = new JLabel(" " + track5Attempts);
        track5AttemptsLabel.setBounds(425, 331, 30, 13);
        getContentPane().add(track5AttemptsLabel);
        loadGameState();
        track6AttemptsLabel = new JLabel(" " + track6Attempts);
        track6AttemptsLabel.setBounds(178, 331, 20, 13);
        getContentPane().add(track6AttemptsLabel);
        loadGameState();
        track7AttemptsLabel = new JLabel(" " + track7Attempts);
        track7AttemptsLabel.setBounds(548, 331, 30, 13);
        getContentPane().add(track7AttemptsLabel);
        loadGameState();
     

     // Create a label to display the player's name 
     playerNameLabel = new JLabel();
     playerNameLabel.setBounds(327, 4, 200, 13);
     playerNameLabel.setFont(playerNameLabel.getFont().deriveFont(Font.BOLD, 14f));
     getContentPane().add(playerNameLabel);  // Add the player's name label to the content pane

     // Update the player's name label 
     updatePlayerNameLabel();
     loadGameState();
     // Add a background image to the content pane
     ImageIcon backgroundImageIcon = new ImageIcon("Media/bg.png");
     JLabel backgroundLabel = new JLabel(backgroundImageIcon);
     backgroundLabel.setBounds(0, 4, 800, 522);
     getContentPane().add(backgroundLabel);
        
    } // This method saves the game state to a file
    private void saveGameState() {
        try (PrintWriter out = new PrintWriter(new FileOutputStream(initials + "_gamestate.txt"))) {
            out.println(score);
            out.println(level);
            out.println(difficulty); 
       
            out.println(track2Attempts);
            out.println(track3Attempts);
            out.println(track4Attempts);
            out.println(track5Attempts);
            out.println(track6Attempts);
            out.println(track7Attempts);
            out.println(maxNumber);

            System.out.println("Game state saved successfully.");
        } catch (IOException e) {
            System.out.println("Error saving game state: " + e.getMessage());
        }
    }
    // This method Loads the game state to a file
    private void loadGameState() {
        try (Scanner scanner = new Scanner(new FileInputStream(initials + "_gamestate.txt"))) {
            score = scanner.nextInt();
            level = scanner.nextInt();
            difficulty = scanner.next();  // Load the difficulty from the file
            track1Attempts = scanner.nextInt();
            track2Attempts = scanner.nextInt();
            track3Attempts = scanner.nextInt();
            track4Attempts = scanner.nextInt();
            track5Attempts = scanner.nextInt();
            track6Attempts = scanner.nextInt();
            track7Attempts = scanner.nextInt();
         
            System.out.println("Game state loaded successfully.");
        } catch (IOException e) {
            System.out.println("Error loading game state: " + e.getMessage());
        }
    }
  //Change the difficulty level
    private void changeDifficulty(String newDifficulty) {
      difficulty = newDifficulty;
    }

    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                : Generate number
    //
    // Method parameters    :For easy from 1-10000
    //
    // Method return        :Mode 
    //
    // Synopsis                : check all three methods 
    //
    // Modifications        :
    //                            Date            Developer            Notes
    //                            5/6/23            Dhruvit            
    //
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	private void generateMode() {
	    // Initialize the array of numbers
	    numbers1 = new int[1000];
	    numbers2 = new int[1000];
	    numbers3 = new int[1000];
	    numbers4 = new int[1000];
	    numbers5 = new int[1000];
	    numbers6 = new int[1000];
	    numbers7 = new int[1000];
	    
	    Random random = new Random();
	    int minNumber = 1;
	    int maxNumber = 1000 * level;
	    String levelRange = minNumber + " - " + maxNumber;

	    do {
	        generateNumbers(numbers1, random, minNumber, maxNumber);
	        generateNumbers(numbers2, random, minNumber, maxNumber);
	        generateNumbers(numbers3, random, minNumber, maxNumber);
	        generateNumbers(numbers4, random, minNumber, maxNumber);
	        generateNumbers(numbers5, random, minNumber, maxNumber);
	        generateNumbers(numbers6, random, minNumber, maxNumber);
	        generateNumbers(numbers7, random, minNumber, maxNumber);
	        // Generate random numbers for the three arrays and find their modes
            // Repeat until we have unique modes for each array
	        mode1 = findMode(numbers1);
	        mode2 = findMode(numbers2);
	        mode3 = findMode(numbers3);
	        mode4 = findMode(numbers4);
	        mode5 = findMode(numbers5);
	        mode6 = findMode(numbers6);
	        mode7 = findMode(numbers7);
	    } while (hasMultipleModes(mode1, mode2, mode3, mode4, mode5, mode6, mode7));

	
	}
	 // This method populates an array with random numbers within a given range
	private void generateNumbers(int[] numbers, Random random, int minNumber, int maxNumber) {
	    for (int i = 0; i < 1000; i++) {
	        numbers[i] = random.nextInt(maxNumber - minNumber + 1) + minNumber;
	    }
	}
	 // This method finds the mode (most frequent number) in an array
	private int findMode(int[] numbers) {
	    int element = 0;
	    int count = 0;

	    for (int j = 0; j < numbers.length; j++) {
	        int tempElement = numbers[j];
	        int tempCount = 0;

	        for (int p = 0; p < numbers.length; p++) {
	            if (numbers[p] == tempElement) {
	                tempCount++;
	            }
	        }

	        if (tempCount > count) {
	            element = tempElement;
	            count = tempCount;
	        }
	    }

	    return element;
	}
	 // This method checks if there are multiple identical modes among Seven given modes
	private boolean hasMultipleModes(int mode1, int mode2, int mode3, int mode4, int mode5, int mode6, int mode7) {
	    return (mode1 == mode2 && mode1 != mode3 && mode1 != mode4 && mode1 != mode5 && mode1 != mode6 && mode1 != mode7)
	        || (mode1 == mode3 && mode1 != mode2 && mode1 != mode4 && mode1 != mode5 && mode1 != mode6 && mode1 != mode7)
	        || (mode1 == mode4 && mode1 != mode2 && mode1 != mode3 && mode1 != mode5 && mode1 != mode6 && mode1 != mode7)
	        || (mode1 == mode5 && mode1 != mode2 && mode1 != mode3 && mode1 != mode4 && mode1 != mode6 && mode1 != mode7)
	        || (mode1 == mode6 && mode1 != mode2 && mode1 != mode3 && mode1 != mode4 && mode1 != mode5 && mode1 != mode7)
	        || (mode1 == mode7 && mode1 != mode2 && mode1 != mode3 && mode1 != mode4 && mode1 != mode5 && mode1 != mode6)
	        || (mode2 == mode3 && mode2 != mode1 && mode2 != mode4 && mode2 != mode5 && mode2 != mode6 && mode2 != mode7)
	        || (mode2 == mode4 && mode2 != mode1 && mode2 != mode3 && mode2 != mode5 && mode2 != mode6 && mode2 != mode7)
	        || (mode2 == mode5 && mode2 != mode1 && mode2 != mode3 && mode2 != mode4 && mode2 != mode6 && mode2 != mode7)
	        || (mode2 == mode6 && mode2 != mode1 && mode2 != mode3 && mode2 != mode4 && mode2 != mode5 && mode2 != mode7)
	        || (mode2 == mode7 && mode2 != mode1 && mode2 != mode3 && mode2 != mode4 && mode2 != mode5 && mode2 != mode6)
	        || (mode3 == mode4 && mode3 != mode1 && mode3 != mode2 && mode3 != mode5 && mode3 != mode6 && mode3 != mode7)
	        || (mode3 == mode5 && mode3 != mode1 && mode3 != mode2 && mode3 != mode4 && mode3 != mode6 && mode3 != mode7)
	        || (mode3 == mode6 && mode3 != mode1 && mode3 != mode2 && mode3 != mode4 && mode3 != mode5 && mode3 != mode7)
	        || (mode3 == mode7 && mode3 != mode1 && mode3 != mode2 && mode3 != mode4 && mode3 != mode5 && mode3 != mode6)
	        || (mode4 == mode5 && mode4 != mode1 && mode4 != mode2 && mode4 != mode3 && mode4 != mode6 && mode4 != mode7)
	        || (mode4 == mode6 && mode4 != mode1 && mode4 != mode2 && mode4 != mode3 && mode4 != mode5 && mode4 != mode7)
	        || (mode4 == mode7 && mode4 != mode1 && mode4 != mode2 && mode4 != mode3 && mode4 != mode5 && mode4 != mode6)
	        || (mode5 == mode6 && mode5 != mode1 && mode5 != mode2 && mode5 != mode3 && mode5 != mode4 && mode5 != mode7)
	        || (mode5 == mode7 && mode5 != mode1 && mode5 != mode2 && mode5 != mode3 && mode5 != mode4 && mode5 != mode6)
	        || (mode6 == mode7 && mode6 != mode1 && mode6 != mode2 && mode6 != mode3 && mode6 != mode4 && mode6 != mode5);
	}

	
	// Method to change the level
	private void changeLevel() {
		// Increase the level
	    level++;
		
	    // Add the remaining attempts from the current level and any bonus attempts to the total attempts for the next level
        track1Attempts += (11 + bonusAttempts);
        track2Attempts += (11 + bonusAttempts);
        track3Attempts += (11 + bonusAttempts);
        track4Attempts += (11 + bonusAttempts);
        track5Attempts += (11 + bonusAttempts);
        track6Attempts += (11 + bonusAttempts);
        track7Attempts += (11 + bonusAttempts);
        bonusAttempts = 0;
	 // Clear the list of guessed numbers
        guessedNumbers.clear();
		// Reset the text fields and enable them for the next level
	    track1.setText("");
	    track2.setText("");
	    track3.setText("");
	    track4.setText("");
	    track5.setText("");
	    track6.setText("");
	    track7.setText("");
	    track1.setEnabled(true);
	    track2.setEnabled(true);
	    track3.setEnabled(true);
	    track4.setEnabled(true);
	    track5.setEnabled(true);
	    track6.setEnabled(true);
	    track7.setEnabled(true);
		
		// Reset the guess indicators
	    guessIndicator1.setText("");
	    guessIndicator2.setText("");
	    guessIndicator3.setText("");
	    guessIndicator4.setText("");
	    guessIndicator5.setText("");
	    guessIndicator6.setText("");
	    guessIndicator7.setText("");
	    previousGuessLabel1.setText("");
        previousGuessLabel2.setText("");
        previousGuessLabel3.setText("");
        previousGuessLabel4.setText("");
        previousGuessLabel5.setText("");
        previousGuessLabel6.setText("");
        previousGuessLabel7.setText("");

	    if (level >= 1 && level <= 10) {
            maxNumber = level * 1000;
        }
        levelRangeLabel.setText("Range: 1 - " + maxNumber);
		// Set the focus to the first text field
	    track1.requestFocus();

		// Update the attempts label
	    track1AttemptsLabel.setText("" + track1Attempts);
        track2AttemptsLabel.setText("" + track2Attempts);
        track3AttemptsLabel.setText("" + track3Attempts);
        track4AttemptsLabel.setText("" + track4Attempts);
        track5AttemptsLabel.setText("" + track5Attempts);
        track6AttemptsLabel.setText("" + track6Attempts);
        track7AttemptsLabel.setText("" + track7Attempts);
		
		// Update the level label
	    updateLevelLabel();

		// Generate modes for the next level
	    generateMode();

		// Clear the correct guesses
	    correctGuesses.clear();
		
		
		
		// Update the score label
	    updateScoreLabel();
	    
	}

	// Method to update the level label
	private void updateLevelLabel() {
		level1.setText(String.valueOf(level));
	 }

	// Method to update the score label
	private void updateScoreLabel() {
	     score1.setText(String.valueOf(score));
	 }

    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
    // Method                :  Check guess check attempts and score and tracks
    //
    // Method parameters    :to check every tracks and attmepts and score
    //
    // Method return        :
    //
    // Synopsis                : 
    //
    // Modifications        :
    //                            Date            Developer            Notes
    //                            5/6/23            Dhruvit            
    //
    //
    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-= 
	// This method is used to check if the user's guess is correct
	private void checkGuess() {
	    // If the user is out of attempts, show a message
	    if (( track1Attempts == 0) ||
	            ( track2Attempts == 0) ||
	            ( track3Attempts == 0)||
	            ( track4Attempts == 0)||
	            ( track5Attempts == 0)||
	            ( track6Attempts == 0)||
	            ( track7Attempts == 0)) {
	        JOptionPane.showMessageDialog(this, "Out of attempts for this track");
	        userProfile.setScore(score);  // Save the score to the user's profile
	        // Ask the user if they want to restart the game
	        int option = JOptionPane.showConfirmDialog(this, "Game Over! Do you want to restart the game?", "Game Over", JOptionPane.YES_NO_OPTION);
	        // If the user wants to restart, call the restartGame method
	        if (option == JOptionPane.YES_OPTION) {
	        	showGameOverMessage();
	            restartGame();
	        } else {
	            // If the user does not want to restart, close the application
	            System.exit(0);
	        }
	        return;
	    }

	    // Initialize all guess variables
	    int guess1, guess2, guess3, guess4, guess5, guess6, guess7;

	    // Attempt to parse the text from each JTextField into an integer
	    try {
	        guess1 = Integer.parseInt(track1.getText());
	        guess2 = Integer.parseInt(track2.getText());
	        guess3 = Integer.parseInt(track3.getText());
	        guess4 = Integer.parseInt(track4.getText());
	        guess5 = Integer.parseInt(track5.getText());
	        guess6 = Integer.parseInt(track6.getText());
	        guess7 = Integer.parseInt(track7.getText());
	    } catch (NumberFormatException e) {
	        // If the text cannot be parsed into an integer, show an error message
	        JOptionPane.showMessageDialog(this, "Invalid input. Please enter a number.");
	        return;
	    }
	 
	    if (guess1 < 1 || guess1 > maxNumber || guess2 < 1 || guess2 > maxNumber || guess3 < 1 || guess3 > maxNumber|| guess4 > maxNumber || guess4 < 1 || guess5 > maxNumber|| guess5 < 1|| guess6 > maxNumber || guess6 < 1 || guess7 > maxNumber|| guess7 < 1) {
            JOptionPane.showMessageDialog(this, "Invalid guess. Please enter a number between 1 and " + maxNumber + ".");
            return;
        } 
        
     
	    // Assume that all guesses are correct until proven otherwise
	    boolean allCorrect = true;

	 // For track 1
	    if (guess1 != mode1 && !guessedTracks.contains(1)) {
	        allCorrect = false;  // Mark that not all guesses are correct
	        if (guess1 < mode1) {  // If the guess is lower than the mode
	            guessIndicator1.setText("↑");  // Set the indicator to show guess needs to be higher
	            sign1.setText("X");  // Mark this guess as incorrect
	        } else {  // If the guess is higher than the mode
	            sign1.setText("X");  // Mark this guess as incorrect
	            guessIndicator1.setText("↓");  // Set the indicator to show guess needs to be lower
	        }
	        track1Attempts--;
	    } else {  // If the guess is correct or has been guessed before

	        guessedTracks.add(1);  // Add this track to the set of guessed tracks
	        sign1.setText("✓");  // Mark this guess as correct
	        track1.setEnabled(false);  // Disable the input for this track as it has been correctly guessed
	        guessIndicator1.setEnabled(false);  // Disable the guess indicator for this track
	        if (!correctGuesses.contains(1)) {  // If this track hasn't been correctly guessed before
	        	int spareGuesses = track1Attempts;

	              while(spareGuesses > 0) {
	                if (spareGuesses >= 3) {
	                    score += 50; // Bonus points for guessing in 3 attempts or less
	spareGuesses -= 3;
	                }
	                else {
	                     score += 10 * spareGuesses;
	spareGuesses -= 1;
	                } 
                userProfile.setScore(score); // Add 10 points for a correct guess
	            correctGuesses.add(1);  // Add this track to the set of correctly guessed tracks
	        }
	    }
	}
	    // Repeat the same process for each track. Replace "1" with "2", "3", "4", "5", "6", "7" for the corresponding tracks.

	        if (guess2 != mode2 && !guessedTracks.contains(2)) {
	            allCorrect = false;
	            if (guess2 < mode2) {
	                guessIndicator2.setText("↑‘");
	                sign2.setText("X");
	            } else {
	                guessIndicator2.setText("↓");
	                sign2.setText("X");
	            }
	            track2Attempts--;
	        } else {
	            
	            guessedTracks.add(2);
	            sign2.setText("✓");
	            track2.setEnabled(false);
	            guessIndicator2.setEnabled(false);
	            if (!correctGuesses.contains(2)) {
	            	int spareGuesses = track2Attempts;

	                while(spareGuesses > 0) {
	                  if (spareGuesses >= 3) {
	                      score += 50; // Bonus points for guessing in 3 attempts or less
	  spareGuesses -= 3;
	                  }
	                  else {
	                       score += 10 * spareGuesses;
	  spareGuesses -= 1;
	                  }  userProfile.setScore(score);// Add 10 points for a correct guess on track 5
	                correctGuesses.add(2);
	            }
	        }
	        }
	        if (guess3 != mode3 && !guessedTracks.contains(3)) {
	            allCorrect = false;
	            if (guess3 < mode3) {
	                guessIndicator3.setText("↑");
	                sign3.setText("X");
	            } else {
	                guessIndicator3.setText("↓");
	                sign3.setText("X");
	            }
	            track3Attempts--;
	        } else {
	            
	            guessedTracks.add(3);
	            sign3.setText("✓");
	            track3.setEnabled(false);
	            guessIndicator3.setEnabled(false);
	            if (!correctGuesses.contains(3)) {
	            	int spareGuesses = track3Attempts;

	                while(spareGuesses > 0) {
	                  if (spareGuesses >= 3) {
	                      score += 50; // Bonus points for guessing in 3 attempts or less
	  spareGuesses -= 3;
	                  }
	                  else {
	                       score += 10 * spareGuesses;
	  spareGuesses -= 1;
	                  }  userProfile.setScore(score);// Add 10 points for a correct guess on track 5
	                correctGuesses.add(3);
	            }
	        }
	        }
	        if (guess4 != mode4 && !guessedTracks.contains(4)) {
	            allCorrect = false;
	            if (guess4 < mode4) {
	                guessIndicator4.setText("↑");
	                sign4.setText("X");
	            } else {
	                guessIndicator4.setText("↓");
	                sign4.setText("X");
	            }
	            track4Attempts--;
	        } else {
	         
	            guessedTracks.add(4);
	            sign4.setText("✓");
	            track4.setEnabled(false);
	            guessIndicator4.setEnabled(false);
	            if (!correctGuesses.contains(4)) {
	            	int spareGuesses = track4Attempts;

	                while(spareGuesses > 0) {
	                  if (spareGuesses >= 3) {
	                      score += 50; // Bonus points for guessing in 3 attempts or less
	  spareGuesses -= 3;
	                  }
	                  else {
	                       score += 10 * spareGuesses;
	  spareGuesses -= 1;
	                  }  userProfile.setScore(score);// Add 10 points for a correct guess on track 5
	                correctGuesses.add(4);
	            }
	        }
	        }
	        if (guess5 != mode5 && !guessedTracks.contains(5)) {
	            allCorrect = false;
	            if (guess5 < mode5) {
	                guessIndicator5.setText("↑");
	                sign5.setText("X");
	                
	            } else {
	                guessIndicator5.setText("↓");
	                sign5.setText("X");
	            }
	            track5Attempts--;
	        } else {
	         
	            guessedTracks.add(5);
	           sign5.setText("✓");
	            track5.setEnabled(false);
	            guessIndicator5.setEnabled(false);
	            if (!correctGuesses.contains(5)) {
	            	int spareGuesses = track5Attempts;

	                while(spareGuesses > 0) {
	                  if (spareGuesses >= 3) {
	                      score += 50; // Bonus points for guessing in 3 attempts or less
	  spareGuesses -= 3;
	                  }
	                  else {
	                       score += 10 * spareGuesses;
	  spareGuesses -= 1;
	                  }   userProfile.setScore(score);// Add 10 points for a correct guess on track 5
	                correctGuesses.add(5);
	            }
	        }
	}
	        
	        if (guess6 != mode6) {
	            allCorrect = false;
	            if (guess6 < mode6) {
	                guessIndicator6.setText("↑");
	                sign6.setText("X");
	            } else {
	            	sign6.setText("X");
	            	guessIndicator6.setText("↓");
	            }
	            track6Attempts--;
	        } else {
	          
	            sign6.setText("✓");
	            track6.setEnabled(false);
	            guessIndicator6.setEnabled(false);
	            if (!correctGuesses.contains(6)) {
	            	int spareGuesses = track6Attempts;

	                while(spareGuesses > 0) {
	                  if (spareGuesses >= 3) {
	                      score += 50; // Bonus points for guessing in 3 attempts or less
	  spareGuesses -= 3;
	                  }
	                  else {
	                       score += 10 * spareGuesses;
	  spareGuesses -= 1;
	                  }   userProfile.setScore(score);// Add 10 points for a correct guess on track 7
	                correctGuesses.add(6);
	            }
	        }
	}
	        
	        if (guess7 != mode7) {
	            allCorrect = false;
	            if (guess7 < mode7) {
	              
	            	guessIndicator7.setText("↑");
	            	sign7.setText("X");
	            } else {
	                guessIndicator7.setText("↓");
	                sign7.setText("X");
	            }
	            track7Attempts--;
	        } else {
	           
	            sign7.setText("✓");
	            track7.setEnabled(false);
	            guessIndicator7.setEnabled(false);
	            if (!correctGuesses.contains(7)) {
	            	int spareGuesses = track7Attempts;

	                while(spareGuesses > 0) {
	                  if (spareGuesses >= 3) {
	                      score += 50; // Bonus points for guessing in 3 attempts or less
	  spareGuesses -= 3;
	                  }
	                  else {
	                       score += 10 * spareGuesses;
	  spareGuesses -= 1;
	                  }   userProfile.setScore(score);// Add 10 points for a correct guess on track 7
	                correctGuesses.add(7);
	            }	        }
	        
	        }
	        

	     // If all the guesses are correct
	        if (allCorrect) {
	            // Add the number of rows in the guess table to the correct guesses set

	            
	            // If all tracks have been guessed correctly
	            if (correctGuesses.size() == tracks) {
	                // Show a dialog message that the level is completed and move to the next level
	                JOptionPane.showMessageDialog(this, "Level completed! Moving to next level...");

	                // Calculate and add bonus points for remaining guesses
	              
	                // Update user profile with the new score
	                userProfile.setScore(score);
	                
	                // Reset the attempts for the next level
	              
	                // Proceed to the next track
	                changeTrack();
	            } else {
	            	
	                // Not all tracks have been guessed correctly
	                // Display a message to user to guess remaining tracks
	                JOptionPane.showMessageDialog(this, "Correct! Guess the remaining tracks...");
	                // Update the attempts label
	                nextLevelButton.setEnabled(true);
	                track1AttemptsLabel.setText("" + track1Attempts);
	                track2AttemptsLabel.setText("" + track2Attempts);
	                track3AttemptsLabel.setText("" + track3Attempts);
	                track4AttemptsLabel.setText("" + track4Attempts);
	                track5AttemptsLabel.setText("" + track5Attempts);
	                track6AttemptsLabel.setText("" + track6Attempts);
	                track7AttemptsLabel.setText("" + track7Attempts);

	                // Clear the input fields and enable them for the next round of guesses
	                track1.setText("");
	                track2.setText("");
	                track3.setText("");
	                track4.setText("");
	                track5.setText("");
	                track6.setText("");
	                track7.setText("");
	                track1.setEnabled(true);
	                track2.setEnabled(true);
	                track3.setEnabled(true);
	                track4.setEnabled(true);
	                track5.setEnabled(true);
	                track6.setEnabled(true);
	                track7.setEnabled(true);

	                // Clear the guess indicators
	                guessIndicator1.setText("");
	                guessIndicator2.setText("");
	                guessIndicator3.setText("");
	                guessIndicator4.setText("");
	                guessIndicator5.setText("");
	                guessIndicator6.setText("");
	                guessIndicator7.setText("");

	                // Set focus to the first track input field
	                track1.requestFocus();

	                // Disable the guess button
	                guessButton.setEnabled(false);
	            }
	        } else {
	        	
	            	
	                // If not all the player's guesses are correct, decrement the number of attempts
	               // If there are no attempts left
	            	if (track1Attempts == 0 && track2Attempts == 0 && track3Attempts == 0&& track4Attempts == 0 && track5Attempts == 0&& track6Attempts == 0 && track7Attempts == 0) {
	                    JOptionPane.showMessageDialog(this, "Out of attempts for all tracks!");
	                    userProfile.setScore(score); // Save the score to the user's profile
	                    int option = JOptionPane.showConfirmDialog(this, "Game Over! Do you want to restart the game?", "Game Over", JOptionPane.YES_NO_OPTION);
	                    if (option == JOptionPane.YES_OPTION) {
	                    	showGameOverMessage();
	                        restartGame();
	                    } else {
	                        System.exit(0);
	                    }
	                    return;
	                
	                }
	            }

	        // Display the guesses in their respective labels
	        guessLabel1.setText(Integer.toString(guess1));
	        guessLabel2.setText(Integer.toString(guess2));
	        guessLabel3.setText(Integer.toString(guess3));
	        guessLabel4.setText(Integer.toString(guess4));
	        guessLabel5.setText(Integer.toString(guess5));
	        guessLabel6.setText(Integer.toString(guess6));
	        guessLabel7.setText(Integer.toString(guess7));

	        // Update the attempts label
	     // Update the attempts labels after each guess
	        track1AttemptsLabel.setText("" + track1Attempts);
	        track2AttemptsLabel.setText("" + track2Attempts);
	        track3AttemptsLabel.setText("" + track3Attempts);
	        track4AttemptsLabel.setText("" + track4Attempts);
	        track5AttemptsLabel.setText("" + track5Attempts);
	        track6AttemptsLabel.setText("" + track6Attempts);
	        track7AttemptsLabel.setText("" + track7Attempts);
	        
	        
	        
	        // Display previous guesses in the labels
	        previousGuessLabel1.setText(Integer.toString(guess1));
	        previousGuessLabel2.setText(Integer.toString(guess2));
	        previousGuessLabel3.setText(Integer.toString(guess3));
	        previousGuessLabel4.setText(Integer.toString(guess4));
	        previousGuessLabel5.setText(Integer.toString(guess5));
	        previousGuessLabel6.setText(Integer.toString(guess6));
	        previousGuessLabel7.setText(Integer.toString(guess7));
	        // Clear the set of guessed tracks
	        guessedTracks.clear();

	        // Update the score label
	        updateScoreLabel();
	    }
	 
	 
		// Method to restart the game
		private void restartGame() {
			// Reset the score, level, attempts, bonus attempts and current track
		        score = 0;
		        level = 1;
		        track1Attempts = 11;
		        track2Attempts = 11;
		        track3Attempts = 11;
		        track4Attempts = 11;
		        track5Attempts = 11;
		        track6Attempts = 11;
		        track7Attempts = 11;
		        
		        track1AttemptsLabel.setText("" + track1Attempts);
		        track2AttemptsLabel.setText("" + track2Attempts);
		        track3AttemptsLabel.setText("" + track3Attempts);
		        track4AttemptsLabel.setText("" + track4Attempts);
		        track5AttemptsLabel.setText("" + track5Attempts);
		        track6AttemptsLabel.setText("" + track6Attempts);
		        track7AttemptsLabel.setText("" + track7Attempts);
		        bonusAttempts = 0;
		        currentTrack = 1;
			
			// Clear correct guesses, completed levels and guessed tracks
		        correctGuesses.clear();
		        completedLevels.clear();
		        guessedTracks.clear();
		        if (level >= 1 && level <= 9) {
		            maxNumber = level * 1000;
		        }
		        levelRangeLabel.setText("Range: 1 - " + maxNumber);
			// Reset all track text fields
		        track1.setText("");
		        track2.setText("");
		        track3.setText("");
		        track4.setText("");
		        track5.setText("");
		        track6.setText("");
		        track7.setText("");
			
			// Enable all track text fields
		        track1.setEnabled(true);
		        track2.setEnabled(true);
		        track3.setEnabled(true);
		        track4.setEnabled(true);
		        track5.setEnabled(true);
		        track6.setEnabled(true);
		        track7.setEnabled(true);
			
			// Reset all guess indicators
		        guessIndicator1.setText("");
		        guessIndicator2.setText("");
		        guessIndicator3.setText("");
		        guessIndicator4.setText("");
		        guessIndicator5.setText("");
		        guessIndicator6.setText("");
		        guessIndicator7.setText("");
			
			// Clear the guess table

		        previousGuessLabel1.setText("");
		        previousGuessLabel2.setText("");
		        previousGuessLabel3.setText("");
		        previousGuessLabel4.setText("");
		        previousGuessLabel5.setText("");
		        previousGuessLabel6.setText("");
		        previousGuessLabel7.setText("");
			// Update the score and level labels
		        updateScoreLabel();
		        updateLevelLabel();
			
			// Generate mode for the first level
		        generateMode();
			
			// Set the focus to the first track text field
		        track1.requestFocus();
		    }

		// Method to update the player name label
		private void updatePlayerNameLabel() {
			// Set the label text to include the player's name from the user profile
		        playerNameLabel.setText("Player: " + userProfile.getPlayerName());
		    }
		  //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
	    // Method                :  Track and level is inset in this to complete all track add bonus attempts 
	    //
	    // Method parameters    :Store bonus attempts 
	    //
	    // Method return        :
	    //
	    // Synopsis                : 
	    //
	    // Modifications        :
	    //                            Date            Developer            Notes
	    //                            5/6/23            Dhruvit            
	    //
	    //
	    //=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=
		// Define a method to change the current track
		private void changeTrack() {
		    // Extend totalTracks array to include track6 and track7
		    JTextField[] totalTracks = {track1, track2, track3, track4, track5, track6, track7};
		    int totalLevels = 9;  // Total number of levels remain same

		    // Check if the current track is less than the total number of tracks (now 7)
		    if (currentTrack < totalTracks.length) {
		        currentTrack++;  // If so, increment the current track
		    } else {
		        // If not, check if the level is less than the total number of levels
		        if (level < totalLevels) {
		            level++;  // If so, increment the level
		            currentTrack = 1;  // And reset the current track to 1
		            userProfile.addCompletedLevels(level);  // Update the user profile with completed level
		            updateLevelLabel();  // Update the level label to reflect the change
		        } else {
		            // If all levels are completed, show a congratulations message
		            JOptionPane.showMessageDialog(this, "Congratulations! You've finished all the levels.");
		            showGameOverMessage();  // Show the game over message
		            return;
		        }
		    }

		    // If all levels are completed, show a congratulations message
		    if (completedLevels.size() == totalLevels) {
		        JOptionPane.showMessageDialog(this, "Congratulations! You've finished all the levels.");
		        showGameOverMessage();  // Show the game over message
		        return;
		    }

		    // Enable all tracks and clear their text
		    for (JTextField totalTrack : totalTracks) {
		        totalTrack.setEnabled(true);
		        totalTrack.setText(""); // Clear the text fields
		    }

		    // Enable all guess indicators (now 7)
		    guessIndicator1.setEnabled(true);
		    guessIndicator2.setEnabled(true);
		    guessIndicator3.setEnabled(true);
		    guessIndicator4.setEnabled(true);
		    guessIndicator5.setEnabled(true);
		    guessIndicator6.setEnabled(true);
		    guessIndicator7.setEnabled(true);

		    // Generate the new mode for the game
		    generateMode();

		    // Clear all guess indicators (now 7)
		    guessIndicator1.setText("");
		    guessIndicator2.setText("");
		    guessIndicator3.setText("");
		    guessIndicator4.setText("");
		    guessIndicator5.setText("");
		    guessIndicator6.setText("");
		    guessIndicator7.setText("");
		 // Clear the previous guess labels
	        previousGuessLabel1.setText("");
	        previousGuessLabel2.setText("");
	        previousGuessLabel3.setText("");
	        previousGuessLabel4.setText("");
	        previousGuessLabel5.setText("");
	        previousGuessLabel6.setText("");
	        previousGuessLabel7.setText("");
		    // Set the focus to the first track
		    track1.requestFocus();

		    userProfile.setScore(score);  // Update the score in the user profile

		    // If there are no more attempts left, reset the attempts to 7
		    if (track1Attempts  <= 0) {
	        	track1Attempts  = 11; // Reset attempts only when no attempts are remaining
	        }
	        if (track2Attempts  <= 0) {
	        	track2Attempts  = 11; // Reset attempts only when no attempts are remaining
	        }
	        if (track3Attempts  <= 0) {
	        	track3Attempts  = 11; // Reset attempts only when no attempts are remaining
	        }
	        if (track4Attempts  <= 0) {
	        	track4Attempts  = 11; // Reset attempts only when no attempts are remaining
	        }
	        if (track5Attempts  <= 0) {
	        	track5Attempts  = 11; // Reset attempts only when no attempts are remaining
	        }
	        if (track6Attempts  <= 0) {
	        	track6Attempts  = 11; // Reset attempts only when no attempts are remaining
	        }
	        if (track7Attempts  <= 0) {
	        	track7Attempts  = 11; // Reset attempts only when no attempts are remaining
	        }
		    // Clear the list of guessed numbers
		    guessedNumbers.clear();

		    // Clear the table

		    // Clear all correct guesses
		    correctGuesses.clear();
		    
		    updateLevelLabel();  // Update the level label to reflect the change
		}


	    // This method shows a game over message when the game ends.
	    private void showGameOverMessage() {
	        // Create a string to hold the message. Start it with "Game Over!\n".
	        String message = "Game Over!\n";

	        // Add the player's name to the message string.
	        message += "Player: " + userProfile.getPlayerName() + "\n";

	        // Add the player's score to the message string.
	        message += "Score: " + userProfile.getScore() + "\n";
	        message += "Level"+level+"\n";
	        // Note: This method currently doesn't actually show the message anywhere.
	        // It creates the message string, but then doesn't do anything with it.
	        // To show the message, you could use something like JOptionPane.showMessageDialog(null, message);
	    }



	  
 
}
