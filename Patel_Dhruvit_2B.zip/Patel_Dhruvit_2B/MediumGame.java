
import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Random;

 class MediumGame extends JFrame {
	
	private static final long serialVersionUID = 1L;
	private JLabel lblGuess, scoreLabel, trackLabel, levelLabel, score1, track1, level1;
	 private JTextField guessField1, guessField2, guessField3, guessField4, guessField5;
    private JButton guessButton;
    private ArrayList<Integer> correctGuesses = new ArrayList<>();
    private int level ; 
    private int tracks;
    private int attempts;
    private int score;
    private int currentTrack;
    private JTable guessTable;
    private DefaultTableModel tableModel;
    private JLabel guessIndicator;
	private int mode;

    public MediumGame() {
        initialize();
        changeTrack();
        
       
    }

	private void initialize() {
    	

        setTitle("Medium Level");
        setSize(538, 435);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        getContentPane().setLayout(null);

        lblGuess = new JLabel("GUESS");
        lblGuess.setBounds(10, 91, 54, 13);
        getContentPane().add(lblGuess);
        guessIndicator = new JLabel("");
        guessIndicator.setBounds(74, 154, 168, 60);

        getContentPane().add(guessIndicator);

        guessField1 = new JTextField(5);
        guessField1.setBounds(74, 88, 45, 19);
        getContentPane().add(guessField1);

        guessField2 = new JTextField(6);
        guessField2.setBounds(74, 125, 45, 19);
        getContentPane().add(guessField2);

        guessField3 = new JTextField(6);
        guessField3.setBounds(129, 88, 45, 19);
        getContentPane().add(guessField3);

        guessField4 = new JTextField(6);
        guessField4.setBounds(129, 125, 45, 19);
        getContentPane().add(guessField4);

        guessField5 = new JTextField(6);
        guessField5.setBounds(99, 154, 45, 19);
        getContentPane().add(guessField5);
        
     // Initialize the JTable and its model
        tableModel = new DefaultTableModel();
        tableModel.addColumn("Track");
        tableModel.addColumn("Guess");
        tableModel.addColumn("Level");
        tableModel.addColumn("Correct");

        
        guessTable = new JTable(tableModel);
     // Set the cell renderer here
     guessTable.getColumnModel().getColumn(1).setCellRenderer(new DefaultTableCellRenderer() {
         /**
		 * 
		 */
		private static final long serialVersionUID = 1L;

		@Override
         public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
             super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
             if (correctGuesses.contains(row)) {
                 setBackground(Color.GREEN);
             } else {
                 setBackground(Color.WHITE);
             }
             return this;
         }
     });


        JScrollPane scrollPane = new JScrollPane(guessTable);
        scrollPane.setBounds(211, 5, 301, 383);
        getContentPane().add(scrollPane);

        guessButton = new JButton("Play");
        guessButton.setBounds(88, 183, 59, 21);
        getContentPane().add(guessButton);
        guessButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                checkGuess();
            }
        });

        scoreLabel = new JLabel("Score: ");
        scoreLabel.setBounds(12, 5, 84, 13);
        getContentPane().add(scoreLabel);
        
        levelLabel = new JLabel("Level: ");
        levelLabel.setBounds(12, 35, 84, 13); // adjust the position as needed
        getContentPane().add(levelLabel);

        level1 = new JLabel("0");
        level1.setBounds(64, 35, 45, 13); // adjust the position as needed
        getContentPane().add(level1);

        trackLabel = new JLabel("Track: ");
        trackLabel.setBounds(12, 20, 84, 13);
        getContentPane().add(trackLabel);

        score1 = new JLabel("0");
        score1.setBounds(64, 5, 45, 13);
        getContentPane().add(score1);

        track1 = new JLabel("0");
        track1.setBounds(64, 20, 45, 13);
        getContentPane().add(track1);

        attempts = 7;
    }
	private void calculateMode(int[] numbers) {
	    int maxCount = 0;
	    int mode = numbers[0];
	    for (int i = 0; i < numbers.length; ++i) {
	        int count = 0;
	        for (int j = 0; j < numbers.length; ++j) {
	            if (numbers[j] == numbers[i]) ++count;
	        }
	        if (count > maxCount) {
	            maxCount = count;
	            mode = numbers[i];
	        }
	    }
	this.mode = mode;
	    this.mode1 = mode;
	    this.mode2 = mode;
	    this.mode3 = mode;
	    this.mode4 = mode;
	    this.mode5 = mode;

	}

	private void generateMode() {
	    Random random = new Random();
	    mode1 = random.nextInt(10 * level) + 1;
	    mode2 = random.nextInt(10 * level) + 1;
	    mode3 = random.nextInt(10 * level) + 1;
	    mode4 = random.nextInt(10 * level) + 1;
	    mode5 = random.nextInt(10 * level) + 1;


	    guessField1.setText(String.valueOf(mode1));
	    guessField2.setText(String.valueOf(mode2));
	    guessField3.setText(String.valueOf(mode3));
	    guessField4.setText(String.valueOf(mode4));
	    guessField5.setText(String.valueOf(mode5));

	    int[] numbers = new int[1000];
	    for (int i = 0; i < 1000; i++) {
	        numbers[i] = random.nextInt(10 * level) + 1;
	    }

	    calculateMode(numbers);
	}

	private void checkGuess() {
	    if (tracks == 0) {
	        changeTrack();
	        return;
	    }

	    int guess1 = Integer.parseInt(guessField1.getText());
	    int guess2 = Integer.parseInt(guessField2.getText());
	    int guess3 = Integer.parseInt(guessField3.getText());
	    int guess4 = Integer.parseInt(guessField4.getText());
	    int guess5 = Integer.parseInt(guessField5.getText());

	    boolean allCorrect = true;

	    if (guess1 != mode1) {
	        allCorrect = false;
	        tableModel.addRow(new Object[]{currentTrack, guess1, level, "No"});
	    }

	    if (guess2 != mode2) {
	        allCorrect = false;
	        tableModel.addRow(new Object[]{currentTrack, guess2, level, "No"});
	    }

	    if (guess3 != mode3) {
	        allCorrect = false;
	        tableModel.addRow(new Object[]{currentTrack, guess3, level, "No"});
	    }
	    if (guess4 != mode4) {
	        allCorrect = false;
	        tableModel.addRow(new Object[]{currentTrack, guess4, level, "No"});
	    }
	    if (guess5 != mode5) {
	        allCorrect = false;
	        tableModel.addRow(new Object[]{currentTrack, guess5, level, "No"});
	    }

	    if (allCorrect) {
	        correctGuesses.add(guessTable.getRowCount() - 1);
	        guessIndicator.setText("");
	        JOptionPane.showMessageDialog(this, "Correct! Moving to next track...");
	        score += 10 * attempts;
	        if (attempts >= 3) {
	            score += 50;
	        }
	        tracks--;
	        attempts = 5;
	        generateMode();
	        guessField1.setText(""); // Clear guess fields
	        guessField2.setText("");
	        guessField3.setText("");
	        guessField4.setText("");
	        guessField5.setText("");

	        // Remove incorrect guesses from the table
	        for (int i = tableModel.getRowCount() - 1; i >= 0; i--) {
	            if (tableModel.getValueAt(i, 3).equals("No")) {
	                tableModel.removeRow(i);
	            }
	        }
	    } else {
	        attempts--;
	        if (attempts == 0) {
	            guessIndicator.setText("");
	            JOptionPane.showMessageDialog(this, "Out of attempts for this track! Moving to next track...");
	            tracks--;
	            attempts = 5;
	            generateMode();
	        } else {
	            StringBuilder indicatorText = new StringBuilder();
	            if (guess1 < mode1) {
	                indicatorText.append("↑ Guess 1 is too low. ");
	            } else if (guess1 > mode1) {
	                indicatorText.append("↓ Guess 1 is too high. ");
	            }

	            if (guess2 < mode2) {
	                indicatorText.append("↑ Guess 2 is too low. ");
	            } else if (guess2 > mode2) {
	                indicatorText.append("↓ Guess 2 is too high. ");
	            }

	            if (guess3 < mode3) {
	                indicatorText.append("↑ Guess 3 is too low. ");
	            } else if (guess3 > mode3) {
	                indicatorText.append("↓ Guess 3 is too high. ");
	            }
	            if (guess4 < mode4) {
	                indicatorText.append("↑ Guess 4 is too low. ");
	            } else if (guess4 > mode4) {
	                indicatorText.append("↓ Guess 4 is too high. ");
	            }
	            if (guess5 < mode5) {
	                indicatorText.append("↑ Guess 5 is too low. ");
	            } else if (guess5 > mode5) {
	               
	                indicatorText.append("↓ Guess 5 is too high. ");
	            }

	            guessIndicator.setText(indicatorText.toString());
	        }
	    }
	    updateScoreLabel();
	}



    
    private void updateLevelLabel() {
        level1.setText(String.valueOf(level));
    }

    private void updateScoreLabel() {
        score1.setText(String.valueOf(score));
    }

    private void changeTrack() {
        if (currentTrack < 3) { // Check if we still have tracks
            currentTrack++;
            level++;  // increment level
            updateLevelLabel(); // update level label
            track1.setText(String.valueOf(currentTrack));
            tracks = 3;
            attempts = 5;
            generateMode();

            // Clear the guessField, guessTable, and correctGuesses list for the new track
            guessField1.setText("");
            guessField2.setText("");
            guessField3.setText("");
            correctGuesses.clear();
            for (int i = tableModel.getRowCount() - 1; i >= 0; i--) {
                tableModel.removeRow(i);
            }

            // Display correct guess for the completed track
           
        } else {
            level = 1;  // reset level
            updateLevelLabel(); // update level label
            JOptionPane.showMessageDialog(this, "Correct guess: " + mode1 + ", " + mode2 + ", " + mode3+ ", " + mode4+ ", " + mode5);
            JOptionPane.showMessageDialog(this, "Congratulations! You've finished all the tracks.");
        }
    }



     public static void main(String[] args) {
    SwingUtilities.invokeLater(new Runnable() {
        @Override
        public void run() {
            new MediumGame().setVisible(true);
        }
    });
}
}